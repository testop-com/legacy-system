@extends('layout.master')

@section('title')
    Guias de Saida
@endsection
@php
$i = 1;
$ano = null;
@endphp
@section('content')

    <div class="page-content fade-in-up" id="requisicao-armazem">
        <div class="row">
            <div class="col-md-12">

                <div class="ibox">

                    <div class="ibox-head bg-blue-100">
                        <div class="ibox-title" style="text-transform: uppercase; font-weight: 800">{{ __('tables.Guias de Saida') }}</div>
                        <div class=" ">
                            @if (Auth::user()->tipo_de_usuario == 0 || Auth::user()->tipo_de_usuario != 4 || Auth::user()->tipo_de_usuario == 1)
                                <a class="btn btn-sm btn-success br" href="{{ route('guiasaida.create') }}">
                                    <i class="fa fa-plus"></i> {{ __('tables.Registar Saida') }}
                                </a>
                            @endif
                        </div>
                    </div>

                    <div class="ibox-body">


                        <table class="table table-striped" id="myTable">
                            <thead class="bg-blue-100" >
                                <tr>
                                    <th>&nbsp; Ord</th>
                                    {{--  <th>&nbsp; Empresa</th>  --}}
                                    <th>&nbsp; Nr./Ref</th>
                                    <th class="{{ Auth::user()->tipo_de_usuario == 7 ? '' : 'd-none' }} ">&nbsp; {{ __('tables.Projecto') }}</th>
                                    <th >&nbsp; Site {{ Auth::user()->tipo_de_usuario == 7 ? '(Destino)' : ''}}</th>
                                    <th>&nbsp; {{ __('tables.Data') }} </th>
                                    <th>&nbsp; {{ __('tables.Requisitante') }}</th>
                                    <th style="font-size: 12px" class="text-center">{{ __('tables.Anexo (doc. Assinado)') }}</th>
                                    <th class="text-center">{{ __('tables.Estado') }}</th>
                                    <th class="text-center">{{ __('tables.Acções') }}</th> 
                                </tr>
                            </thead>
                            <tbody> 
                                @php
                                    $i = 1;
                                    $an = 1;
                                @endphp
                                @foreach ($saidas as $data)
                                    <tr>
                                        <td style="font-size: 14px">&nbsp; {{ $i++ }}</td>
                                        {{--  <td style="font-size: 14px">&nbsp; {{ $data->empresa->nome }}</td>  --}}
                                        <td style="font-size: 14px">
                                            <a href="{{ route('guiasaida.show', ['id' => $data->id]) }}" >
                                                &nbsp;{{ $data->numero_do_folheto }}
                                            </a>
                                        </td> 
                                        <td  class="{{ Auth::user()->tipo_de_usuario == 7 ? '' : 'd-none' }} " style="font-size: 14px">
                                            &nbsp; {{ $data->nome_projecto }}
                                        </td>
                                        <td style="font-size: 14px">
                                            &nbsp; {{ $data->nome_site }}
                                        </td>
                                        <td style="font-size: 14px">&nbsp; {{ $data->data }}</td>
                                        <td style="font-size: 14px">&nbsp; {{ $data->requisitante }}</td> 
                                        <td style="font-size: 12px" class="text-center">
                                            @if ($data->anexo)
                                                <a href="{{ asset('public/anexos/system/' . $data->anexo . '') }}"
                                                    class="text-success">
                                                    <i class="fa fa-print"></i> Anexo ({{ $an++ }})
                                                </a>
                                            @else
                                                <a href="#" class="text-danger">
                                                    <i class="fa fa-times"></i> <i>Sem anexo</i>
                                                </a>
                                            @endif
                                        </td>
                                        <td class="text-center">
                                            @if ($data->pendente == 0)
                                                <span style="border-radius: 12px" class="badge badge-danger  badge-sm badge-rounded  mt-1">
                                                    cancelado <i class="fa fa-times"></i>
                                                </span>   
                                            @else
                                                @if ($data->pendente == 2 || $data->pendente == 3)
                                                    <span style="border-radius: 12px" class="badge badge-success badge-sm badge-rounded  mt-1">
                                                        Aprovado <i class="fa fa-check"></i>
                                                    </span>
                                                @elseif ($data->pendente == 1)
                                                    <span style="border-radius: 12px" class="badge badge-warning  badge-sm badge-rounded  mt-1">
                                                        Pendente <i class="fa fa-warning"></i>
                                                    </span>                                                     
                                                @endif
                                            @endif
                                            

                                        </td>


                                        <th class="text-center">
                                            <a href="{{ route('guiasaida.show', ['id' => $data->id]) }}" class="btn btn-info btn-sm m-r-5 btn-rounded " data-original-title="Ver detalhes">
                                                <i class="fa fa-search-plus"></i>
                                            </a>

                                            @if ($data->pendente == 1)
                                                <a href="{{ route('guiasaida.delete', ['id' => $data->id]) }}" class="btn btn-danger btn-sm m-r-5 btn-rounded " data-original-title="Remover">
                                                    <i class="fa fa-trash"></i>
                                                </a> 
                                            @else
                                                <a href="#go" class="btn btn-success btn-sm m-r-5 btn-rounded ">
                                                    <i class="fa fa-check"></i>
                                                </a>
                                            @endif
                                            
                                        </th>
                                    </tr>
                                @endforeach
                            </tbody> 
                        </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


@endsection

