 
<div class="page-content fade-in-up" id="entradas-saidas">
    <div class="row">
        <div class="col-md-12">
            <div class="ibox">
                <div class="ibox-head bg-blue-100">
                    <ul class="nav nav-tabs {{ Request::is('stock/entradas_saidas-pesquisa') ? 'd-none' : '' }}">
                        <li class="nav-item ">
                            <a class="nav-link active" href="{{ route('stock.entradasaida') }}" style="text-transform: uppercase; font-weight: 800">{{ __('reports.Projectos: entradas & saidas') }}</a>
                        </li>
                       
                        <li class="nav-item">
                            <a class="nav-link " href="{{ route('stock.site_entradasaida') }}"  style="text-transform: uppercase; font-weight: 800">
                            {{ __('reports.Sites: entradas & saidas') }}
                            </a>
                        </li>
                        <li class="nav-item d-none">
                            <a class="nav-link" href="{{ route('stock.site_entradasaida_geral') }}"  style="text-transform: uppercase; font-weight: 800">
                            {{ __('reports.Sites: Geral') }}
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('stock.site_entradasaida_flow') }}"  style="text-transform: uppercase; font-weight: 800">
                            {{ __('reports.Sites: Stock Flow') }}
                            </a>
                        </li>

                    </ul>
                    <div class="ibox-tools">
                        <a class="ibox-collapse"><i class="fa fa-minus"></i></a>
                    </div>
                </div>
                <div class="ibox-body pt-5">
                    <section>
                        <div class="row justify-content-between">
                            <div class="col-md-12">
                                <div class="row">
                                    <div class="col-md-6">
                                        <form id="pesquisaData">
                                            <div class="row">
                                                <div class="col-md-4 form-group">
                                                    <label for="">{{ __('reports.Data Inicio') }}:</label>
                                                    <input type="date" class="form-control br" name="datainicio"
                                                        v-model="produto.datainicio" v-on:input="search">
                                                </div>
                                                <div class="col-md-4 form-group">
                                                    <label for="">{{ __('reports.Data Fim') }}:</label>
                                                    <input type="date" class="form-control br" name="datafim"
                                                        v-model="produto.datafim" v-on:input="search">
                                                </div>
                                                <div class="col-md-4 form-group">
                                                    <label for="">{{ __('reports.Projecto') }}:</label>
                                                    <select class="form-control br" v-on:change="search" v-model="produto.projecto" name="projecto">
                                                        <option value="0" selected disabled hidden>{{ __('reports.Todos Projectos') }}</option>
                                                        @foreach ($projectos as $projecto)
                                                            <option value="{{ $projecto->id }}">
                                                                {{ $projecto->nome }}
                                                            </option>
                                                        @endforeach
                                                    </select>
                                                </div>

                                            </div>

                                        </form>
                                    </div>

                                    <div class="col-md-3">
                                        <form action="">
                                            <div class="form-group">
                                                <label for="">{{ __('reports.Pesquisa geral') }}:</label>
                                                <input type="text" class="form-control br" placeholder="Pesquisa" name="pesquisa"
                                                    v-model="produto.pesquisa" v-on:input="search">
                                            </div>
                                            @csrf
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-9 d-none">
                                <form action="{{ route('stockfilter.pesquisa') }}" method="post">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <input type="text" class="form-control " placeholder="Codigo"
                                                    name="codigo" v-model="produto.codigo" v-on:input="search">
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <input type="text" class="form-control " placeholder="Nome" name="nome"
                                                    v-model="produto.nome" v-on:input="search">
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <input type="text" class="form-control " placeholder="Subcategoria"
                                                    name="subcategoria" v-model="produto.subcategoria"
                                                    v-on:input="search">
                                            </div>
                                        </div>
                                    </div>

                                    @csrf
                                </form>
                            </div>
                            
                        </div>
                    </section>
                    <table class="table table-hover table-dashed table-striped" id="entradasSaidas-table" >
                        <thead class="bg-blue-100" >
                            <tr>
                                <th style="font-size: 13px" class="text-center"># &nbsp;</th>
                                <th style="font-size: 13px"> &nbsp; {{ __('tables.Codigo') }} &nbsp;</th>
                                <th style="white-space: nowrap; font-size: 13px">&nbsp; {{ __('tables.Nome') }} &nbsp;</th>
                                <th style="white-space: nowrap; font-size: 13px">&nbsp; {{ __('tables.Projecção') }} &nbsp;</th>   
                                <th style="text-align: right; white-space: nowrap;font-size: 13px">{{ __('tables.Entrada') }} &nbsp;</th>
                                <th style="text-align: right; white-space: nowrap;font-size: 13px">{{ __('tables.Saida') }} &nbsp;</th> 
                                <th style="text-align: right; white-space: nowrap;font-size: 13px">{{ __('tables.Saldo') }} &nbsp;</th>
                            </tr>
                        </thead>
                        <tbody v-if="produtos.length!==0" v-html="produtos">
                        </tbody>
                        <tbody v-else> 
                            <tr>
                                <td colspan="6" class="text-center text-danger"  >
                                {{ __('tables.Sem registos!') }}'
                                </td>
                            </tr>
                        </tbody>
                    </table>

                    <div class="d-flex justify-content-end">

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
