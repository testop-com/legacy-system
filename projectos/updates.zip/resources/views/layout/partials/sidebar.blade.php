<nav class="page-sidebar pl-1" id="sidebar" style="position: fixed;">
    <div id="sidebar-collapse">

        <div class="admin-block d-flex">
            <div>
                <img src="{{ asset('assets/img/admin-avatar.png') }}" width="45px" />
            </div>
            <div class="admin-info">
                <div class="font-strong">{{ Auth::user()->username }}</div>
                <small>{{ App\Models\TipoUsuario::where('tipo', Auth::user()->tipo_de_usuario)->first()['nome'] }}</small>
            </div>
        </div>

        @php
            $locale = app()->getLocale();
        @endphp
        
        <ul class="side-menu metismenu">
            <li>
                <a class="active" href="{{ route('dashboard.index') }}">
                    <i class="sidebar-item-icon fa fa-th-large"></i>
                    <span class="nav-label">{{ __('sidebar.Dashboard') }}</span>
                </a>
            </li>

            <li class="heading text-center">
                <hr style="border-top: 1px solid #f5f5f536; margin-top: 0; margin-bottom: 0">
                {{ __('sidebar.Recursos Principais') }}
                <hr style="border-top: 1px solid #f5f5f536; margin-top: 0; margin-bottom: 0">
            </li>

            <li>
                <a href="javascript:;">
                    <i class="sidebar-item-icon fa fa-expand"></i>
                    <span class="nav-label">{{ __('sidebar.Ajuste & Transf.') }}</span><i class="fa fa-angle-left arrow"></i>
                </a>
                <ul class="nav-2-level collapse">
                    <li><a href="{{ route('transferencias.index') }}">{{ __('sidebar.Transferências') }}</a></li>
                    <li><a href="{{ route('ajusteentrada.index') }}">{{ __('sidebar.Aj. Entrada') }}</a></li>
                    <li><a href="{{ route('ajustesaida.index') }}">{{ __('sidebar.Aj. Saida') }}</a></li>
                </ul>
            </li>

            <li>
                <a href="javascript:;">
                    <i class="sidebar-item-icon fa fa-bookmark"></i>
                    <span class="nav-label">{{ __('sidebar.Guias Projectos') }}</span><i class="fa fa-angle-left arrow"></i>
                </a>
                <ul class="nav-2-level collapse">
                    <li><a href="{{ route('guiaentrada.index') }}">{{ __('sidebar.Guia de Entrada') }}</a></li>
                    <li><a href="{{ route('guiasaida.index') }}">{{ __('sidebar.Guia de Saida') }}</a></li>
                </ul>
            </li>

            @if (Auth::user()->tipo_de_usuario == 7)
                <li>
                    <a href="javascript:;">
                        <i class="sidebar-item-icon fa fa-home"></i>
                        <span class="nav-label">{{ __('sidebar.Guias Estaleiros') }}</span><i class="fa fa-angle-left arrow"></i>
                    </a>
                    <ul class="nav-2-level collapse">
                        <li><a href="{{ route('guiaentrada_site.index') }}">{{ __('sidebar.Entrada') }}</a></li>
                        <li><a href="{{ route('guiasaida_site.index') }}">{{ __('sidebar.Saida') }}</a></li>
                    </ul>
                </li>
            @endif

            <li>
                <a href="javascript:;">
                    <i class="sidebar-item-icon fa fa-hospital-o"></i>
                    <span class="nav-label">{{ __('sidebar.Guias EDM') }}</span><i class="fa fa-angle-left arrow"></i>
                </a>
                <ul class="nav-2-level collapse">
                    <li><a href="{{ route('guiaentrada.index.edm') }}">{{ __('sidebar.Entradas') }}</a></li>
                    <li><a href="{{ route('guiasaida.index_stock_edm') }}">{{ __('sidebar.Saidas') }}</a></li>
                </ul>
            </li>

            <li>
                <a href="javascript:;">
                    <i class="sidebar-item-icon fa fa-shopping-bag"></i>
                    <span class="nav-label">{{ __('sidebar.Requisições') }}</span><i class="fa fa-angle-left arrow"></i>
                </a>
                <ul class="nav-2-level collapse">
                    <li><a href="{{ route('requisicao.index') }}">{{ __('sidebar.Armazem') }}</a></li>
                    @if (Auth::user()->tipo_de_usuario == 7)
                        <li><a href="{{ route('requisicao.projectos') }}">{{ __('sidebar.Projectos') }}</a></li>
                    @endif
                </ul>
            </li>

            <li>
                <a href="javascript:;">
                    <i class="sidebar-item-icon fa fa-pie-chart"></i>
                    <span class="nav-label">{{ __('sidebar.Projectos') }}</span><i class="fa fa-angle-left arrow"></i>
                </a>
                <ul class="nav-2-level collapse">
                    <li><a href="{{ route('projecto.index') }}">{{ __('sidebar.Meus Projectos') }}</a></li>
                </ul>
                <ul class="nav-2-level collapse">
                    <li><a href="{{ route('projeccao.index') }}">{{ __('sidebar.Projecção') }}</a></li>
                </ul>
            </li>

            <li>
                <a href="{{ route('produto_imagem.index') }}">
                    <i class="sidebar-item-icon fa fa-picture-o"></i>
                    <span class="nav-label">{{ __('sidebar.Imagens de Materiais') }}</span>
                </a>
            </li>

            <li class="heading text-center d-none">
                <hr style="border-top: 1px solid #f5f5f536; margin-top: 0; margin-bottom: 0">
                {{ __('sidebar.Baixadas') }}
                <hr style="border-top: 1px solid #f5f5f536; margin-top: 0; margin-bottom: 0">
            </li>

            <li class="d-none">
                <a href="javascript:;">
                    <i class="sidebar-item-icon fa fa-bolt"></i>
                    <span class="nav-label">{{ __('sidebar.Gestão de baixadas') }}</span><i class="fa fa-angle-left arrow"></i>
                </a>
                <ul class="nav-2-level collapse">
                    <li><a href="{{ route('baixada.entrada') }}">{{ __('sidebar.Entradas') }}</a></li>
                    <li><a href="{{ route('baixada.saida') }}">{{ __('sidebar.Execução') }}</a></li>
                    <li><a href="{{ route('baixada.report') }}">{{ __('sidebar.Relatórios') }}</a></li>
                </ul>
            </li>

            <li class="heading text-center">
                <hr style="border-top: 1px solid #f5f5f536; margin-top: 0; margin-bottom: 0">
                {{ __('sidebar.Relatorios') }}
                <hr style="border-top: 1px solid #f5f5f536; margin-top: 0; margin-bottom: 0">
            </li>

            <li>
                <a href="javascript:;">
                    <i class="sidebar-item-icon fa fa-bar-chart"></i>
                    <span class="nav-label">{{ __('sidebar.Relatório de Stock') }}</span><i class="fa fa-angle-left arrow"></i>
                </a>
                <ul class="nav-2-level collapse">
                    <li class="d-none"><a href="{{ route('stock.site_entradasaida_geral') }}">{{ __('sidebar.Geral') }}</a></li>
                    <li><a href="{{ route('stock.site_entradasaida') }}">{{ __('sidebar.Sites') }}</a></li>
                    <li class="{{ Auth::user()->tipo_de_usuario == 7 ? '' : 'd-none' }}"><a href="{{ route('stock.entradasaida') }}">{{ __('sidebar.Projectos') }}</a></li>
                    <li><a href="{{ route('stock.site_edm_entradasaida') }}">{{ __('sidebar.Stock EDM') }}</a></li>
                </ul>
            </li>

            <!--
            <li>
                <a href="javascript:;">
                    <i class="sidebar-item-icon fa fa-language"></i>
                    <span class="nav-label">{{ __('sidebar.Idioma') }}</span><i class="fa fa-angle-left arrow"></i>
                </a>
                <ul class="nav-2-level collapse">
                    <li>
                        <a href="/language-switch?locale=en"
                        class="{{ $locale === 'en' ? 'text-primary font-bold' : '' }}">
                        {{ __('sidebar.English') }}
                        </a>
                    </li>
                    <li>
                        <a href="/language-switch?locale=pt-Br"
                        class="{{ $locale === 'pt-Br' ? 'text-primary font-bold' : '' }}">
                        {{ __('sidebar.Português') }}
                        </a>
                    </li>
                </ul>
            </li>
            -->
        </ul>
    </div>
</nav>
