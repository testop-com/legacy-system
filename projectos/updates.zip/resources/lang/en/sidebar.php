
<?php

return [
    'Dashboard' => 'Dashboard',
    'Ajuste & Transf.' => 'Adjustment & Transfer',
    'Transferências' => 'Transfers',
    'Aj. Entrada' => 'Adj. Entry',
    'Aj. Saida' => 'Adj. Exit',
    'Guias Projectos' => 'Project Guides',
    'Guia de Entrada' => 'Entry Guide',
    'Guia de Saida' => 'Exit Guide',
    'Guias Estaleiros' => 'Site Guides',
    'Recursos Principais' => 'Main Resources',
    'Entrada' => 'Entry',
    'Saida' => 'Exit',
    'Guias EDM' => 'EDM Guides',
    'Entradas' => 'Entries',
    'Saidas' => 'Exits',
    'Requisições' => 'Requests',
    'Armazem' => 'Warehouse',
    'Projectos' => 'Projects',
    'Meus Projectos' => 'My Projects',
    'Imagens de Materiais' => 'Material Images',
    'Gestão de baixadas' => 'Dropped Materials Management',
    'Execução' => 'Execution',
    'Relatórios' => 'Reports',
    'Relatorios' => 'Reports',
    'Relatório de Stock' => 'Stock Report',
    'Geral' => 'General',
    'Sites' => 'Sites',
    'Stock EDM' => 'EDM Stock',
    'Idioma' => 'Language',
    'English' => 'English',
    'Português' => 'Portuguese',
    'Projecção' => 'Projection'
];

?>