
<?php

return [
    'Dashboard' => 'Dashboard',
    'Ajuste & Transf.' => 'Ajuste & Transf.',
    'Transferências' => 'Transferências',
    'Aj. Entrada' => 'Aj. Entrada',
    'Aj. Saida' => 'Aj. Saída',
    'Guias Projectos' => 'Guias Projectos',
    'Guia de Entrada' => 'Guia de Entrada',
    'Guia de Saida' => 'Guia de Saída',
    'Guias Estaleiros' => 'Guias Estaleiros',
    'Recursos Principais' => 'Recursos Principais',
    'Entrada' => 'Entrada',
    'Saida' => 'Saída',
    'Guias EDM' => 'Guias EDM',
    'Entradas' => 'Entradas',
    'Saidas' => 'Saídas',
    'Requisições' => 'Requisições',
    'Armazem' => 'Armazém',
    'Projectos' => 'Projectos',
    'Meus Projectos' => 'Meus Projectos',
    'Imagens de Materiais' => 'Imagens de Materiais',
    'Gestão de baixadas' => 'Gestão de baixadas',
    'Execução' => 'Execução',
    'Relatorios' => 'Relatórios',
    'Relatórios' => 'Relatórios',
    'Relatório de Stock' => 'Relatório de Stock',
    'Geral' => 'Geral',
    'Sites' => 'Sites',
    'Stock EDM' => 'Stock EDM',
    'Idioma' => 'Idioma',
    'English' => 'Inglês',
    'Português' => 'Português',
    'Projecção' => 'Projecção'
];

?>