<?php

use App\Http\Controllers\AjusteEntradaController;
use App\Http\Controllers\AjusteEntradaProdutoController;
use App\Http\Controllers\AjusteSaidaController;
use App\Http\Controllers\AjusteSaidaProdutoController; 
use Illuminate\Support\Facades\Route;  
use App\Http\Controllers\DashboardController; 
use App\Http\Controllers\GuiaDeEntradaController;
use App\Http\Controllers\GuiaDeRemessaController;
use App\Http\Controllers\GuiaDeSaidaController;
use App\Http\Controllers\GuiaDeTransporteController;
use App\Http\Controllers\GuiaEntradaProdutoController;
use App\Http\Controllers\GuiaSaidaProdutoController; 
use App\Http\Controllers\PesquisasController;
use App\Http\Controllers\StockController;
use App\Http\Controllers\ProdutoController;  
use App\Http\Controllers\RequisicaoArmazemController;
use App\Http\Controllers\RequisicaoArmazemProdutoController;
use App\Http\Controllers\ProjectoStockFilterDataController; 
use App\Http\Controllers\SiteStockFilterDataController;   
use App\Http\Controllers\ProjectoController;
use App\Http\Controllers\ProdutoImagemController;
use App\Http\Controllers\TransferenciaStockController;
use App\Http\Controllers\TransferenciaProdutoStockController;
use App\Http\Controllers\ProjeccaoStockController;
use App\Http\Controllers\AjusteStockProjectadoController;
use App\Http\Controllers\AjusteFilterDataControllerSite;
use App\Http\Controllers\AjusteFilterDataControllerProjecto;
use App\Http\Controllers\BaixadaController;
use App\Http\Controllers\StockEdmSiteFilterDataController;
use App\Http\Controllers\SiteStockFilterGeralDataController;
use App\Http\Controllers\SiteStockFilterFlowDataController;
use App\Http\Controllers\Auth\AuthenticatedSessionController;
use App\Http\Controllers\Auth\RegisteredUserController;
use App\Models\Produto;
use App\Http\Controllers\LanguageController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return redirect()->route('dashboard.index');
})->middleware(['auth'])->name('dashboard');
Route::get('/home', function () {
    return redirect()->route('dashboard.index');
})->middleware(['auth'])->name('dashboard');

Route::middleware(['auth'])->group(function () {
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard.index');

    // user
    Route::get('/user/profile', [AuthenticatedSessionController::class, 'profile'])->name('auth.profile');
    Route::post('/user/profile/update', [RegisteredUserController::class, 'update'])->name('auth.update');

    // Requisicao ao armazem projecto
    Route::get('/transferencias/{id}/produto/create', [TransferenciaProdutoStockController::class, 'create'])->name('transferencias_produto.create');
    Route::post('/transferencias_produto/{id}/produto', [TransferenciaProdutoStockController::class, 'store'])->name('transferencias_produto.store');
    Route::get('/transferencias_produto/{id}/produto/index', [TransferenciaProdutoStockController::class, 'index'])->name('transferencias_produto.index');
    Route::delete('/transferencias_produto/{requisicao_id}/produto/{id}/destroy', [TransferenciaProdutoStockController::class, 'destroy'])->name('transferencias_produto.destroy');
    Route::get('/transferencias_produto/{id}/produto/verificar', [TransferenciaProdutoStockController::class, 'confirm'])->name('transferencias_produto.verificar');

    Route::get('/transferencias_stock/aprovar/{id}', [TransferenciaStockController::class, 'aprovar'])->name('transferencia_stock.aprovar');
    Route::resource('/transferencias', TransferenciaStockController::class);

    // Requisicao ao armazem
    Route::any('/requisicaoarmazem/pesquisa', [RequisicaoArmazemController::class, 'pesquisa'])->name('requisicao.pesquisa');
    Route::get('/requisicaoarmazem', [RequisicaoArmazemController::class, 'index'])->name('requisicao.index');
    Route::get('/requisicaoarmazem/projectos', [RequisicaoArmazemController::class, 'index_projectos'])->name('requisicao.projectos');
    Route::get('/requisicaoarmazem/create', [RequisicaoArmazemController::class, 'create'])->name('requisicao.create');
    Route::post('/requisicaoarmazem', [RequisicaoArmazemController::class, 'store'])->name('requisicao.store');
    Route::get('/requisicaoarmazem/{id}', [RequisicaoArmazemController::class, 'show'])->name('requisicao.show');
    Route::get('/requisicaoarmazem/edit_process/{id}', [RequisicaoArmazemController::class, 'edit'])->name('requisicao.edit');
    Route::get('/requisicaoarmazem/{id}/aprovar', [RequisicaoArmazemController::class, 'aprovar'])->name('requisicaoarmazem.aprovar');
    Route::put('/requisicaoarmazem/{id}', [RequisicaoArmazemController::class, 'update'])->name('requisicao.update');
    Route::post('/requisicaoarmazem/{id}/destroy', [RequisicaoArmazemController::class, 'destroy'])->name('requisicao.destroy');
    Route::get('/requisicaoarmazem/delete/{id}', [RequisicaoArmazemController::class, 'delete'])->name('requisicao.delete');
    Route::get('/requisicaoarmazem/{id}/imprimir', [RequisicaoArmazemController::class, 'imprimir'])->name('requisicaoarmazem.imprimir');
    Route::get('/requisicaoarmazem/{id}/imprimir', [RequisicaoArmazemController::class, 'imprimir'])->name('requisicaoarmazem.imprimir');


    Route::post('/requisicao_armazem_projecto/{id}/destroy', [RequisicaoArmazemProjectosController::class, 'destroy'])->name('requisicao_armazem_projecto.destroy');
    Route::get('/requisicao_armazem_projecto/{id}/aprovar', [RequisicaoArmazemProjectosController::class, 'aprovar'])->name('requisicao_armazem_projecto.aprovar');
    Route::get('/requisicao_armazem_projecto/{id}/imprimir', [RequisicaoArmazemProjectosController::class, 'imprimir'])->name('requisicao_armazem_projecto.imprimir');
    Route::get('/requisicao_armazem_projecto/{id}/imprimir', [RequisicaoArmazemProjectosController::class, 'imprimir'])->name('requisicao_armazem_projecto.imprimir');
 
    // Requisicao ao armazem && Produto
    Route::get('/requisicaoarmazem/{id}/produto/index', [RequisicaoArmazemProdutoController::class, 'index'])->name('requisicaoproduto.index');
    Route::get('/requisicaoarmazem/{id}/produto/create', [RequisicaoArmazemProdutoController::class, 'create'])->name('requisicaoproduto.create');
    Route::post('/requisicaoarmazem/{id}/produto', [RequisicaoArmazemProdutoController::class, 'store'])->name('requisicaoproduto.store');
    Route::get('/requisicaoarmazem/{requisicao_id}/produto/{id}/edit', [RequisicaoArmazemProdutoController::class, 'edit'])->name('requisicaoproduto.edit');
    Route::put('/requisicaoarmazem/{requisicao_id}/produto/{id}', [RequisicaoArmazemProdutoController::class, 'update'])->name('requisicaoproduto.update');
    Route::delete('/requisicaoarmazem/{requisicao_id}/produto/{id}/destroy', [RequisicaoArmazemProdutoController::class, 'destroy'])->name('requisicaoproduto.destroy');
    Route::get('/requisicaoarmazem/{id}/produto/verificar', [RequisicaoArmazemProdutoController::class, 'verificar'])->name('requisicaoproduto.verificar');
    Route::get('/requisicaoarmazem/{id}/produto/show', [RequisicaoArmazemProdutoController::class, 'show'])->name('requisicaoproduto.show');


    Route::get('/guiasaida/estaleiro', [GuiaDeSaidaController::class, 'index_estaleiro'])->name('guiasaida_site.index');
    
    // Guia de Saida
    Route::any('/guiasaida/pesquisa', [GuiaDeSaidaController::class, 'pesquisa'])->name('guiasaida.pesquisa');
    Route::get('/guiasaida/index', [GuiaDeSaidaController::class, 'index'])->name('guiasaida.index');
    Route::get('/guiasaida/stock/edm', [GuiaDeSaidaController::class, 'index_stock_edm'])->name('guiasaida.index_stock_edm');
    Route::get('/guiasaida/create', [GuiaDeSaidaController::class, 'create'])->name('guiasaida.create'); 
    Route::post('/guiasaida/store', [GuiaDeSaidaController::class, 'store'])->name('guiasaida.store');
    Route::get('/guiasaida/show/{id}', [GuiaDeSaidaController::class, 'show'])->name('guiasaida.show');
    Route::get('/guiasaida/{id}/edit', [GuiaDeSaidaController::class, 'edit'])->name('guiasaida.edit');
    Route::put('/guiasaida/update/{id}', [GuiaDeSaidaController::class, 'update'])->name('guiasaida.update');
    Route::delete('/guiasaida/{id}/destroy', [GuiaDeSaidaController::class, 'destroy'])->name('guiasaida.destroy');
    Route::get('/guiasaida/{id}/aprovar', [GuiaDeSaidaController::class, 'aprovar'])->name('guiasaida.aprovar');
    Route::get('/guiasaida/{id}/imprimir', [GuiaDeSaidaController::class, 'imprimir'])->name('guiasaida.imprimir');
    Route::get('/guiasaida/pendente/{id}', [GuiaDeSaidaController::class, 'saidas_pendente_by_site'])->name('saida_pend.site');
    Route::get('/guiasaida/delete/{id}', [GuiaDeSaidaController::class, 'delete'])->name('guiasaida.delete');

    
    Route::get('/guiaentrada/estaleiro', [GuiaDeEntradaController::class, 'index_estaleiro'])->name('guiaentrada_site.index');


    // Guia de Saida && Produto
    Route::get('/guiasaida/{id}/produto/index', [GuiaSaidaProdutoController::class, 'index'])->name('guiasaidaproduto.index');
    Route::get('/guiasaida/{id}/produto/create', [GuiaSaidaProdutoController::class, 'create'])->name('guiasaidaproduto.create');
    Route::get('/guiasaida/{id}/produto/verification', [GuiaSaidaProdutoController::class, 'verification'])->name('guiasaidaproduto.verification');
    Route::post('/guiasaida/{id}/produto', [GuiaSaidaProdutoController::class, 'store'])->name('guiasaidaproduto.store');
    Route::get('/guiasaida/{id}/produto/edit', [GuiaSaidaProdutoController::class, 'edit'])->name('guiasaidaproduto.edit');
    Route::put('/guiasaida/{guia_id}/produto/update', [GuiaSaidaProdutoController::class, 'update'])->name('guiasaidaproduto.update');
    Route::get('/guiasaida/{guia_id}/produto/{id}/destroy', [GuiaSaidaProdutoController::class, 'destroy'])->name('guiasaidaproduto.destroy');

    // Guia de Emtrada
    Route::any('/guiaentrada/pesquisa', [GuiaDeEntradaController::class, 'pesquisa'])->name('guiaentrada.pesquisa');
    Route::get('/guiaentrada/index', [GuiaDeEntradaController::class, 'index'])->name('guiaentrada.index');
    Route::get('/guiaentrada/stock/edm', [GuiaDeEntradaController::class, 'index_edm_stock'])->name('guiaentrada.index.edm');
    Route::post('/guiaentrada/store', [GuiaDeEntradaController::class, 'store'])->name('guiadeentrada.store');
    Route::get('/guiaentrada/create', [GuiaDeEntradaController::class, 'create'])->name('guiadeentrada.create');
    Route::post('/guiaentrada/change', [GuiaDeEntradaController::class, 'change'])->name('guiadeentrada.change');
    Route::get('guiaentrada/{id}', [GuiaDeEntradaController::class, 'show'])->name('guiaentrada.show');
    Route::get('/guiaentrada/{id}/edit', [GuiaDeEntradaController::class, 'edit'])->name('guiaentrada.edit');
    Route::put('/guiaentrada/update/{id}', [GuiaDeEntradaController::class, 'update'])->name('guiaentrada.update');
    Route::delete('/guiaentrada/{id}/destroy', [GuiaDeEntradaController::class, 'destroy'])->name('guiaentrada.destroy');
    Route::get('/guiaentrada/{id}/aprovar', [GuiaDeEntradaController::class, 'aprovar'])->name('guiaentrada.aprovar');
    Route::get('/guiaentrada/{id}/envio', [GuiaDeEntradaController::class, 'envio'])->name('guiaentrada.envio');
    Route::get('/guiaentrada/{id}/imprimir', [GuiaDeEntradaController::class, 'imprimir'])->name('guiaentrada.imprimir');
    Route::get('/guiaentrada/delete/{id}', [GuiaDeEntradaController::class, 'delete'])->name('guiaentrada.delete');

    // Guia de Entrada  && Produto
    Route::get('/guiaentrada/{id}/produto/index', [GuiaEntradaProdutoController::class, 'index'])->name('guiaentradaproduto.index');
    Route::get('/guiaentrada/{id}/produto/create', [GuiaEntradaProdutoController::class, 'create'])->name('guiaentradaproduto.create');
    Route::post('/guiaentrada/{id}/produto', [GuiaEntradaProdutoController::class, 'store'])->name('guiaentradaproduto.store');
    Route::get('/guiaentrada/{guia_id}/produto/{id}/edit', [GuiaEntradaProdutoController::class, 'edit'])->name('guiaentradaproduto.edit');
    Route::put('/guiaentrada/{guia_id}/produto/{id}', [GuiaEntradaProdutoController::class, 'update'])->name('guiaentradaproduto.update');
    Route::delete('/guiaentrada/{guia_id}/produto/{id}/destroy', [GuiaEntradaProdutoController::class, 'destroy'])->name('guiaentradaproduto.destroy');
    Route::get('/guiaentrada/{id}/produto/verificar', [GuiaEntradaProdutoController::class, 'verificar'])->name('guiaentradaproduto.verificar');
    Route::get('/guiaentrada/{id}/produto/show', [GuiaEntradaProdutoController::class, 'show'])->name('guiaentradaproduto.show');

    // Guia de Transporte
    Route::any('/guiatransporte/pesquisa', [GuiaDeTransporteController::class, 'pesquisa'])->name('guiatransporte.pesquisa');
    Route::get('/guiatransporte', [GuiaDeTransporteController::class, 'index'])->name('guiatransporte.index');
    Route::post('/guiatransporte', [GuiaDeTransporteController::class, 'store'])->name('guiatransporte.store');
    Route::get('/guiatransporte/create', [GuiaDeTransporteController::class, 'create'])->name('guiadetransporte.create');
    Route::post('/guiatransporte/change', [GuiaDeTransporteController::class, 'change'])->name('guiadetransporte.change');
    Route::get('/guiatransporte/{id}', [GuiaDeTransporteController::class, 'show'])->name('guiatransporte.show');
    Route::get('/guiatransporte/{id}/edit', [GuiaDeTransporteController::class, 'edit'])->name('guiatransporte.edit');
    Route::put('/guiatransporte/{id}', [GuiaDeTransporteController::class, 'update'])->name('guiatransporte.update');
    Route::delete('/guiatransporte/{id}/destroy', [GuiaDeTransporteController::class, 'destroy'])->name('guiatransporte.destroy');
    Route::get('/guiatransporte/{id}/aprovar', [GuiaDeTransporteController::class, 'aprovar'])->name('guiatransporte.aprovar');
    Route::get('/guiatransporte/{id}/imprimir', [GuiaDeTransporteController::class, 'imprimir'])->name('guiatransporte.imprimir');

    // Guia de Remessa
    Route::any('/guiaremessa/pesquisa', [GuiaDeRemessaController::class, 'pesquisa'])->name('guiaremessa.pesquisa');
    Route::get('/guiaremessa', [GuiaDeRemessaController::class, 'index'])->name('guiaremessa.index');
    Route::post('/guiaremessa', [GuiaDeRemessaController::class, 'store'])->name('guiaremessa.store');
    Route::get('/guiaremessa/create', [GuiaDeRemessaController::class, 'create'])->name('guiaderemessa.create');
    Route::post('/guiaremessa/change', [GuiaDeRemessaController::class, 'change'])->name('guiaderemessa.change');
    Route::get('/guiaremessa/{id}', [GuiaDeRemessaController::class, 'show'])->name('guiaremessa.show');
    Route::get('/guiaremessa/{id}/edit', [GuiaDeRemessaController::class, 'edit'])->name('guiaremessa.edit');
    Route::put('/guiaremessa/{id}', [GuiaDeRemessaController::class, 'update'])->name('guiaremessa.update');
    Route::delete('/guiaremessa/{id}/destroy', [GuiaDeRemessaController::class, 'destroy'])->name('guiaremessa.destroy');
    Route::get('/guiaremessa/{id}/aprovar', [GuiaDeRemessaController::class, 'aprovar'])->name('guiaremessa.aprovar');
    Route::get('/guiaremessa/{id}/imprimir', [GuiaDeRemessaController::class, 'imprimir'])->name('guiaremessa.imprimir');


    // Stock
    Route::any('/stock/pesquisa', [StockController::class, 'pesquisa'])->name('stock.pesquisa');
    Route::get('/stock', [StockController::class, 'index'])->name('stock.index');
    Route::get('/stock-pesquisa', [StockController::class, 'stockpage'])->name('stockpages.index');
    Route::post('/stock/produtototal', [StockController::class, 'produtoTotal'])->name('stock.produtototal');

    // Entradas e Saidas de Stock dos projectos
    Route::get('/stock/entradas_saidas', [ProjectoStockFilterDataController::class, 'index'])->name('stock.entradasaida');
    Route::get('/ajustes/{produto_id}', [ProjectoStockFilterDataController::class, 'ajustes_stock'])->name('ajustes_stock');
    Route::get('/stock/entradas_saidas-pesquisa', [ProjectoStockFilterDataController::class, 'stockpage'])->name('stockpages.entradasaida');
    Route::any('/stockfilter/pesquisa', [ProjectoStockFilterDataController::class, 'pesquisa'])->name('stockfilter.pesquisa');

    // Entradas e Saidas de Stock dos Sites
    Route::get('/stock/sites/entradas_saidas', [SiteStockFilterDataController::class, 'index'])->name('stock.site_entradasaida');
    Route::get('/stock/sites/entradas_saidas-pesquisa', [SiteStockFilterDataController::class, 'stockpage'])->name('stockpages.entradasaida');
    Route::any('/stockfilter/sites/pesquisa', [SiteStockFilterDataController::class, 'pesquisa'])->name('stockfilter.sites.pesquisa');

    
    // Entradas e Saidas de Stock dos Sites, Stock da EDM
    Route::get('/stock/edm/sites', [StockEdmSiteFilterDataController::class, 'index'])->name('stock.site_edm_entradasaida');
    Route::get('/stock/edm/sites/pesquisa', [StockEdmSiteFilterDataController::class, 'stockpage'])->name('stockpages.entradasaida_edm');
    Route::any('/stock/edm/filter/sites/pesquisa', [StockEdmSiteFilterDataController::class, 'pesquisa'])->name('stockfilter.sites.pesquisa.edm');

    // Entradas e Saidas de Stock dos Sites Geral
    Route::get('/stock/sites/geral', [SiteStockFilterGeralDataController::class, 'index'])->name('stock.site_entradasaida_geral');  
    Route::get('/stock/sites/flow', [SiteStockFilterFlowDataController::class, 'index'])->name('stock.site_entradasaida_flow');  
    Route::get('/stock/sites/flow/excel/{site_id}', [SiteStockFilterFlowDataController::class, 'excell_fill'])->name('stock.flow.excell_fill');  

    // Ajuste stock
    Route::get('/ajuste/projecto', [AjusteFilterDataControllerProjecto::class, 'index'])->name('ajuste.projecto');
    Route::get('/ajuste/pesquisa/projecto', [AjusteFilterDataControllerProjecto::class, 'stockpage'])->name('ajustepages.entradasaida');
    Route::any('/ajustefilter/pesquisa/projecto', [AjusteFilterDataControllerProjecto::class, 'pesquisa'])->name('ajuste.projecto.filter.pesquisa');

    
    // Ajuste stock
    Route::get('/ajuste/site', [AjusteFilterDataControllerSite::class, 'index'])->name('ajuste.site');
    Route::get('/ajuste/pesquisa/site', [AjusteFilterDataControllerSite::class, 'stockpage'])->name('ajustepages.entradasaida');
    Route::any('/ajustefilter/pesquisa/site', [AjusteFilterDataControllerSite::class, 'pesquisa'])->name('ajuste.site.filter.pesquisa');

    //Produto
    Route::any('/produto/pesquisa', [ProdutoController::class, 'pesquisa'])->name('produto.pesquisa');
    Route::delete('produto/{id}/destroy', [ProdutoController::class, 'destroy'])->name('produto.destroy');
    Route::put('produto/{id}', [ProdutoController::class, 'update'])->name('produto.update');
    Route::get('/produto/{id}/edit', [ProdutoController::class, 'edit'])->name('produto.edit');
    Route::get('/produto', [ProdutoController::class, 'index'])->name('produto.index');
    Route::get('/produto/create', [ProdutoController::class, 'create'])->name('produto.create');
    Route::post('/produto', [ProdutoController::class, 'store'])->name('produto.store');
    Route::get('/produto/{id}/show', [ProdutoController::class, 'show'])->name('produto.show');

    Route::resource('categoria_produto', CategoriaProdutoController::class);  

    Route::get('/pesquisas', [PesquisasController::class, 'index'])->name('pesquisas.index');

    // Ajuste Entrada
    // Guia de Emtrada
    Route::any('/ajusteentrada/pesquisa', [AjusteEntradaController::class, 'pesquisa'])->name('ajusteentrada.pesquisa');
    Route::get('/ajusteentrada', [AjusteEntradaController::class, 'index'])->name('ajusteentrada.index');
    Route::post('/ajusteentrada', [AjusteEntradaController::class, 'store'])->name('ajusteentrada.store');
    Route::get('/ajusteentrada/create', [AjusteEntradaController::class, 'create'])->name('ajusteentrada.create');
    Route::post('/ajusteentrada/change', [AjusteEntradaController::class, 'change'])->name('ajusteentrada.change');
    Route::get('ajusteentrada/{id}', [AjusteEntradaController::class, 'show'])->name('ajusteentrada.show');
    Route::get('/ajusteentrada/{id}/edit', [AjusteEntradaController::class, 'edit'])->name('ajusteentrada.edit');
    Route::put('/ajusteentrada/{id}', [AjusteEntradaController::class, 'update'])->name('ajusteentrada.update');
    Route::delete('/ajusteentrada/{id}/destroy', [AjusteEntradaController::class, 'destroy'])->name('ajusteentrada.destroy');
    Route::get('/ajusteentrada/{id}/aprovar', [AjusteEntradaController::class, 'aprovar'])->name('ajusteentrada.aprovar');
    Route::get('/ajusteentrada/{id}/imprimir', [AjusteEntradaController::class, 'imprimir'])->name('ajusteentrada.imprimir');

    // Guia de Entrada  && Produto
    Route::get('/ajusteentrada/{id}/produto/index', [AjusteEntradaProdutoController::class, 'index'])->name('ajusteentradaproduto.index');
    Route::get('/ajusteentrada/{id}/produto/create', [AjusteEntradaProdutoController::class, 'create'])->name('ajusteentradaproduto.create');
    Route::post('/ajusteentrada/{id}/produto', [AjusteEntradaProdutoController::class, 'store'])->name('ajusteentradaproduto.store');
    Route::get('/ajusteentrada/{guia_id}/produto/{id}/edit', [AjusteEntradaProdutoController::class, 'edit'])->name('ajusteentradaproduto.edit');
    Route::put('/ajusteentrada/{guia_id}/produto/{id}', [AjusteEntradaProdutoController::class, 'update'])->name('ajusteentradaproduto.update');
    Route::delete('/ajusteentrada/{guia_id}/produto/{id}/destroy', [AjusteEntradaProdutoController::class, 'destroy'])->name('ajusteentradaproduto.destroy');
    Route::get('/ajusteentrada/{id}/produto/verificar', [AjusteEntradaProdutoController::class, 'verificar'])->name('ajusteentradaproduto.verificar');
    Route::get('/ajusteentrada/{id}/produto/show', [AjusteEntradaProdutoController::class, 'show'])->name('ajusteentradaproduto.show');

    // Ajuste Saida
    // Guia de Saida
    Route::any('/ajustesaida/pesquisa', [AjusteSaidaController::class, 'pesquisa'])->name('ajustesaida.pesquisa');
    Route::get('/ajustesaida', [AjusteSaidaController::class, 'index'])->name('ajustesaida.index');
    Route::get('/ajustesaida/create', [AjusteSaidaController::class, 'create'])->name('ajustesaida.create');
    Route::post('/ajustesaida', [AjusteSaidaController::class, 'store'])->name('ajustesaida.store');
    Route::get('/ajustesaida/{id}', [AjusteSaidaController::class, 'show'])->name('ajustesaida.show');
    Route::get('/ajustesaida/{id}/edit', [AjusteSaidaController::class, 'edit'])->name('ajustesaida.edit');
    Route::put('/ajustesaida/{id}', [AjusteSaidaController::class, 'update'])->name('ajustesaida.update');
    Route::delete('/ajustesaida/{id}/destroy', [AjusteSaidaController::class, 'destroy'])->name('ajustesaida.destroy');
    Route::get('/ajustesaida/{id}/aprovar', [AjusteSaidaController::class, 'aprovar'])->name('ajustesaida.aprovar');
    Route::get('/ajustesaida/{id}/imprimir', [AjusteSaidaController::class, 'imprimir'])->name('ajustesaida.imprimir');

    // Guia de Saida && Produto
    Route::get('/ajustesaida/{id}/produto/index', [AjusteSaidaProdutoController::class, 'index'])->name('ajustesaidaproduto.index');
    Route::get('/ajustesaida/{id}/produto/create', [AjusteSaidaProdutoController::class, 'create'])->name('ajustesaidaproduto.create');
    Route::get('/ajustesaida/{id}/produto/verification', [AjusteSaidaProdutoController::class, 'verification'])->name('ajustesaidaproduto.verification');
    Route::post('/ajustesaida/{id}/produto', [AjusteSaidaProdutoController::class, 'store'])->name('ajustesaidaproduto.store');
    Route::get('/ajustesaida/{guia_id}/produto/{id}/edit', [AjusteSaidaProdutoController::class, 'edit'])->name('ajustesaidaproduto.edit');
    Route::put('/ajustesaida/{guia_id}/produto/{id}', [AjusteSaidaProdutoController::class, 'update'])->name('ajustesaidaproduto.update');
    Route::delete('/ajustesaida/{guia_id}/produto/{id}/destroy', [AjusteSaidaProdutoController::class, 'destroy'])->name('ajustesaidaproduto.destroy');
    Route::get('/ajustesaida/{id}/produto/verificar', [AjusteSaidaProdutoController::class, 'verificar'])->name('ajustesaidaproduto.verificar');

    
    
    Route::get('/projecto_sites/{id}', [ProjectoController::class, 'projecto_sites'])->name('projecto_sites');

    Route::resource('projecto', ProjectoController::class);
    Route::resource('projeccao', ProjeccaoStockController::class);


    // Adendas e Acrescimos::
    Route::get('/acrescimos/stock', [AjusteStockProjectadoController::class, 'acrescimo'])->name('acrescimo');
    Route::get('/adenda/stock', [AjusteStockProjectadoController::class, 'adenda'])->name('adenda');
    Route::post('/acrescimos/store', [AjusteStockProjectadoController::class, 'acrescimo_store'])->name('acrescimo.store');

    
    //Produto Imagem
    Route::any('/produto_imagem/pesquisa', [ProdutoImagemController::class, 'pesquisa'])->name('produto_imagens.pesquisa');
    Route::get('/produto_imagem', [ProdutoImagemController::class, 'index'])->name('produto_imagem.index');
    Route::get('/produto_imagem/create', [ProdutoImagemController::class, 'create'])->name('produto_imagem.create');
    Route::post('/produto_imagem', [ProdutoImagemController::class, 'store'])->name('produto_imagem.store');
    Route::get('/produto_imagem/{id}/edit', [ProdutoImagemController::class, 'edit'])->name('produto_imagem.edit');
    Route::get('/produto_imagem/{id}', [ProdutoImagemController::class, 'show'])->name('produto_imagem.show');
    Route::put('/produto_imagem/{id}', [ProdutoImagemController::class, 'update'])->name('produto_imagem.update');
    Route::get('/produto_imagem/{id}/destroy', [ProdutoImagemController::class, 'destroy'])->name('produto_imagem.destroy');

    
    // Baixada Module::
    Route::get('/baixada/entrada', [BaixadaController::class, 'entrada'])->name('baixada.entrada');
    Route::get('/baixada/saida', [BaixadaController::class, 'saida'])->name('baixada.saida');
    Route::get('/baixada/report', [BaixadaController::class, 'report'])->name('baixada.report');

    Route::get('guia_saida_pendentes/{empresa_id}', function ($empresa_id) {
        $guias = App\Models\GuiaDeSaida::where([['numero_do_folheto', '<>', 'AJUSTE'], ['empresa_id', $empresa_id], ['status', 1]])->pluck('requisicaoArmazem_id');
        $data = DB::table('requisicao_armazems')->select('id', 'numero_do_folheto')->whereNotIn('requisicao_armazems.id', $guias)->where([['empresa_id', $empresa_id], ['status', 1]])->get();
        return response()->json($data);
    });
    
    Route::get('sites_relacioandos/{projecto}', function ($projecto) {
         
        $data = DB::table('site')->select('id', 'nome')->where([['projecto', $projecto], ['removido', 0]])->get();

        return response()->json($data);
    });
});

Route::get('language-switch', [LanguageController::class, 'switchLanguage'])->name('language.switch');

require __DIR__ . '/auth.php';
