<?php

namespace App\Http\Controllers;

// use App\Models\requisicaoArmazem;
use App\Models\GuiaDeSaida;
use App\Models\Guiadeentrada;
use App\Models\GuiaEntrada_Produto;
use App\Models\GuiaDeTransporte;
use App\Models\GuiaSaidaProduto;
use App\Models\Produto;
use App\Models\Site;
use App\Models\Projecto;
use App\Models\UsuarioProjecto;
use App\Models\RequisicaoArmazem;
use App\Models\RequisicaoArmazem_Produto;
use Illuminate\Http\Request;
use App\Models\Categoria;
use Illuminate\Support\Facades\Auth;
use Barryvdh\DomPDF\Facade as PDF;
use Illuminate\Support\Facades\DB;

class GuiaDeSaidaController extends Controller
{

    protected $user_project;
    public function __construct(UsuarioProjecto $user_project, Guiadeentrada $entrada)
    { 
        $this->user_project = $user_project; 
        $this->entrada = $entrada;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    { 
        $data['requisicao_controller'] = $this;
        $data['saidas'] =  $this->pesquisa(request());
        return view('admin.guiadesaida.index', $data);
    }

    public function index_estaleiro()
    { 
        $data['requisicao_controller'] = $this;
        
        $user_sites = $this->user_project->get_user_sites();
        $data['saidas'] = GuiadeSaida::with(['requisicaoArmazem', 'empresa'])
            ->select('guia_de_saidas.*', 'site.nome as nome_site', 'projecto.nome as nome_projecto')
            ->leftJoin('site', 'site.id', '=', 'guia_de_saidas.site')
            ->leftJoin('projecto', 'projecto.id', '=', 'site.projecto')
            ->where([['empresa_id', '!=', 7], ['guia_de_saidas.numero_do_folheto', '<>', 'AJUSTE'],  ['guia_de_saidas.numero_do_folheto', '<>', 'TRANSFERENCIA'], ['origem', 1], ['role_id', Auth::user()->role_id]])
            ->whereNull('guia_de_saidas.projecto')
            ->whereIn('guia_de_saidas.site', $user_sites)
            ->orderBy('guia_de_saidas.id', 'desc')
        ->get();

        return view('admin.guiadesaida.index', $data);
    }

    public function index_stock_edm()
    {
        $data['requisicao_controller'] = $this;
        $user_sites = $this->user_project->get_user_sites();
        
        $data['saidas'] = GuiadeSaida::with(['requisicaoArmazem', 'empresa'])
            ->select('guia_de_saidas.*', 'site.nome as nome_site', 'projecto.nome as nome_projecto')
            ->leftJoin('site', 'site.id', '=', 'guia_de_saidas.site')
            ->leftJoin('projecto', 'projecto.id', '=', 'guia_de_saidas.projecto')
            ->where([['guia_de_saidas.numero_do_folheto', '<>', 'AJUSTE'],  ['guia_de_saidas.numero_do_folheto', '<>', 'TRANSFERENCIA'], ['origem', 1], ['role_id', Auth::user()->role_id], ['empresa_id', 7]])
            ->whereIn('guia_de_saidas.site', $user_sites)
            ->orderBy('guia_de_saidas.id', 'desc')
        ->get();

        return view('admin.guiadesaida.index_saida_edm', $data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {  
        $data['saida_controller'] = $this;

        
        $site_id = $this->user_project->get_user_sites();
        $project_id = $this->user_project->get_user_projects();
        
        $data['sites'] = DB::table('site')
            ->whereIn('site.id', $site_id)
            ->where('site.removido',0)
        ->get();

        $data['projectos'] = DB::table('projecto')
            ->whereIn('projecto.id', $project_id)
            ->where('projecto.removido',0)
        ->get();

        return view('admin.guiadesaida.create', $data);
    }
 
    
    public function saidas_pendente_by_site($site)
    {
        $role = Auth::user()->role_id;
        return DB::select("SELECT id, numero_do_folheto FROM `requisicao_armazems` where id not in (SELECT requisicaoArmazem_id FROM `guia_de_saidas` where numero_do_folheto not like '%AJUSTE%' and status = 1 and site = $site and role_id = $role and requisicaoArmazem_id is not null) and site = $site and status = 1 and role_id = $role and pendente  = 2;
        ");
        // $guias = GuiaDeSaida::where([['numero_do_folheto', '<>', 'AJUSTE'], ['status', 1], ['site', $site]])->pluck('requisicaoArmazem_id');
        
        // $ids = DB::table('requisicao_armazems')->select('id', 'numero_do_folheto')
        //     ->whereNotIn('requisicao_armazems.id', $guias)
        //     ->where([['status', 1], ['site', $site]])
        // ->pluck('id');a

        // return DB::table('requisicao_armazems')
        //     ->select('id', 'numero_do_folheto')
        //     ->whereIn('id', $ids)
        //     ->orderBy('requisicao_armazems.id', 'DESC')
        // ->get();

    }
 

    public function calculaGuiaNr($saida)
    {
        if ($saida) {
            $guia = $saida;

            $separacao = explode('/', $guia->numero_do_folheto);
            $numero = $separacao['0'];

            $numero = explode('-', $numero)[1];

            $folheto = $numero + 1;
            return $numero_do_folheto = 'TT-'.'000' . $folheto . '/' . date('Y');
        } else {
            return $numero_do_folheto = 'TT-'.'0001' . '/' . date('Y');
        }
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        $validated = $request->validate([   
            'requisitante' => 'required',
            'data' => 'required',
            'elaborado_por' => 'required',
            'anexo' => 'required',
        ]);
 
        try {

            if ($request->has('requisicao_id')) {
                $this->check_qty($request->requisicao_id);

                if ($this->check_qty($request->requisicao_id) > 0) {

                    $this->toaster('error', 'Opps!! Sem stock para emitir Guia de saida!');
                    return redirect()->back();

                }  
            }

            $completeName = '';

            if ($request->hasFile('anexo') && $request->file('anexo')->isValid()) {
                $name = uniqid(date('HisYmd'));
                $type = $request->file('anexo')->extension();
                $completeName =  $name . '.' . $type;
                $request->file('anexo')->move(public_path('./anexos/system'), $completeName);
                $saida['anexo'] = $completeName;
            }

            $saida['numero_do_folheto'] = $this->get_referencia();
            $saida['empresa_id'] = $request->tipo == 2 ? 7 : 1;
            // $saida['site'] = $request->site;
            $saida['site'] = Auth::user()->tipo_de_usuario == 8 ? $request->site : Null;
            $saida['projecto'] = Auth::user()->tipo_de_usuario == 7 ? $request->projecto : Null;
            $saida['requisicaoArmazem_id'] = $request->has('requisicao_id') ? $request->requisicao_id : Null;
            
            $saida['requisitante'] = $validated['requisitante'];
            $saida['data'] = $validated['data'];
            $saida['pendente'] = 1;
            $saida['origem'] = 1;
            $saida['elaborado_por'] = Auth::user()->name. 'Data: ' . date('d/m/Y').'  -  Hora: '.date('H : i : s');

            $data = GuiaDeSaida::create($saida);

            if ($request->has('requisicao_id')) {
                $this->store_prods($request->requisicao_id, $data->id);
            }
 

            $this->toaster('success', 'Guia de saida registada!');
            return redirect()->route('guiasaidaproduto.create', $data->id);

        } catch (\Throwable $error) {
            
            $this->toaster('error', 'Erro ao tentar registar Guia de saida!');
            return redirect()->back()->withErrors($validated);
        }
    }

    function check_qty($requisicao_id){

        $count = 0;
        $processo = RequisicaoArmazem::leftJoin('site', 'site.id', '=', 'requisicao_armazems.site')->find($requisicao_id);
        $produtos = RequisicaoArmazem_Produto::where([['requisicaoArmazem_id',$requisicao_id], ['status', 1]])->get();

        foreach ($produtos as $value) {
            
            $total = $this->quantidade_existente($processo->projecto, Null, $value->produto_id); 

            if ($total < $value->quantidade) {
                $count += 1;
            }
        }

        return $count;
        
        
    }

    public function quantidade_existente($projecto, $site, $produto_id)
    { 
        $produto = Produto::find($produto_id);
        return ($produto->guiaEntradaProdutoProjecto($projecto, $site) - $produto->guiaSaidaProdutoProjecto($projecto, $site)); 
    }

    function store_prods($requisicao_id, $guia_id){

        $produtos = RequisicaoArmazem_Produto::where([['requisicaoArmazem_id',$requisicao_id], ['status', 1]])->get();

        foreach ($produtos as $value) {
            
            GuiaSaidaProduto::create([
                'produto_id' => $value->produto_id,
                'quantidade' => $value->quantidade,
                'guiaSaida_id' => $guia_id
            ]);
        }
        
    }

    public function toaster($type, $message)
    {
        return toastr()->$type($message);
    }

    
    public function get_referencia()
    {
        $guia_saida = DB::table('guia_de_saidas')
            ->where([['numero_do_folheto', '<>', 'AJUSTE'], ['numero_do_folheto', '<>', 'TRANSFERENCIA'], ['origem', 1]])
            ->orderBy('id', 'desc')
        ->first();

        if (date('Y-m-d') == date('Y') . '-01-01') {
            $primeiroDiaDoAno = DB::table('guia_de_saidas')
                ->where('numero_do_folheto', '==', '0001/' . date('Y'))
                ->orderBy('id', 'desc')
                ->first();
            if ($primeiroDiaDoAno) {
                $numero_do_folheto = 'TT-'.$this->calculaGuiaNr($guia_saida);
            } else {
                $numero_do_folheto = 'TT-'.'0001' . '/' . date('Y');
            }
        } else 
        {
            $numero_do_folheto = $this->calculaGuiaNr($guia_saida);
        }

        return $numero_do_folheto;
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    { 
        $data['empresa'] = DB::table('empresa')->get();

        $data['guiasaida'] = GuiaDeSaida::select('guia_de_saidas.*', 'projecto.nome as projecto_nome', 'site.nome as site_nome')
            ->leftJoin('projecto', 'guia_de_saidas.projecto', 'projecto.id')
            ->leftJoin('site', 'guia_de_saidas.site', 'site.id')
        ->find($id);

        if (!$data['guiasaida']) {
            return redirect()->route('guiasaida.index');
        }
        

        $data['requisicaoArmazens'] = RequisicaoArmazem::get();
        return view('admin.guiadesaida.show', $data);
    }

    
    public function delete($id)
    { 
        try {

            GuiaDeSaida::where('id', $id)->delete();
            GuiaSaidaProduto::where('guiaSaida_id', $id)->delete();
            
           
            $this->toaster('success', 'Processo removido com sucesso!'); 
            return redirect()->back();
            
        } catch (\Throwable $error) {
            
            $this->toaster('error', 'Erro ao tentar remover Guia!');
            return redirect()->back();

        }

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $guiasaida = GuiaDeSaida::find($id);
        if (!$guiasaida) {
            return redirect()->route('guiasaida.index');
        }

        $requisicaoArmazems = RequisicaoArmazem::where('pendente', 2)->orWhere('pendente', 3)->get();
        return view('admin.guiadesaida.edit', compact('guiasaida', 'requisicaoArmazems'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $data = $request->validate([ 
            'requisicaoArmazem_id' => '', 
            'empresa_id' => 'required',
            'data' => '',
            'requisitante' => 'required',
            'departamento' => 'required',
            'data_do_documento' => 'required',
            'data_do_fornecimento' => 'required', 
            'levantado_por' => 'required',
            'fiel_do_armazem' => 'required',
            'assistente_do_armazem' => 'required'

        ]);
        $guiasaida = GuiaDeSaida::find($id);

        

        $guiasaida->update([ 
            'empresa_id' => $data['empresa_id'],
            'requisitante' => $data['requisitante'],
            'departamento' => $data['departamento'],
            'data_do_documento' => $data['data_do_documento'],
            'data_do_fornecimento' => $data['data_do_fornecimento'], 
            'levantado_por' => $data['levantado_por'],
            'fiel_do_armazem' => $data['fiel_do_armazem'],
            'assistente_do_armazem' => $data['assistente_do_armazem'],
            'editado_por' => Auth::user()->name. 'Data: ' . date('d/m/Y').'  -  Hora: '.date('H : i : s'),
        ]);

        // GuiaDeTransporte::find($requisicaoArmazemNew)->update(['pendente' => 3]);
        return redirect()->route('guiasaida.show', $id);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        if (!$guia = GuiaDeSaida::where('status', 1)->find($id)) {
            return redirect()->back();
        }

        // Verificar se esta aprovado
        $this->deletar($id);

        return redirect()->route('guiasaida.show', $id);
    }

    public function deletar($id)
    {
        $guia = GuiaDeSaida::where('status', 1)->find($id);

        if (!$guia) {
            return 'vazio';
        }

        Auth::user()->tipo_de_usuario;

        if ($guia->pendente == 2 && Auth::user()->tipo_de_usuario == 1) {

            $guia->update([
                'status' => 0,
                'cancelado_por' => Auth::user()->name. 'Data: ' . date('d/m/Y').'  -  Hora: '.date('H : i : s'),
                'pendente' => 0
            ]);
            return 'Guia de saida pendente 2';
            // return redirect()->route('guiasaida.show', $id);
        } else {
            $guia->update([
                'status' => 0,
                'cancelado_por' => Auth::user()->name. 'Data: ' . date('d/m/Y').'  -  Hora: '.date('H : i : s'),
                'pendente' => 0
            ]);

            return 'Guia de Saida pendente 2';
            // return redirect()->route('guiasaida.show', $id);
        }
    }

    public function count_referencia_entrada($empresa)
    {
        
        $comprasCount = $this->entrada->countByCompany();
        if ($comprasCount > 0) {
            $orderReference = $this->entrada->getLastComprasByEmpresa();

            $ref = explode('-', $orderReference->numero_do_folheto);
            $compras_count = (int) $ref[1];
        } else {
            $compras_count = 0;
        }
 
        $empresa_iniciais = DB::table('empresa')->where('id', $empresa)->first()->iniciais;
        $iniciais = ($empresa_iniciais != null || !empty($empresa_iniciais)) ? $empresa_iniciais : 'ES';

        $referencia =
            $compras_count > 0
            ? $iniciais.'-' .
            sprintf('%04d', $compras_count + 1) .
            '/' .
            date('Y')
        : $iniciais.'-' . 0001;

        return $referencia;

    }

    public function aprovar($id)
    {
        
        
        // DB::beginTransaction();

        try {

            // Processo de aprovacao de uma guia de saida!!
            $user = Auth::user();
            $guia = GuiaDeSaida::find($id);
            
            if (!$guia || $guia->pendente != 1) {
                return redirect()->route('guiasaida.show', $id);
            }
            
            $guia->update([
                'status' => 1,
                'pendente' => 2,
                'aprovado_por' => Auth::user()->name. 'Data: ' . date('d/m/Y').'  -  Hora: '.date('H : i : s'),
                'data_aprovacao' => date('Y-m-d'),
            ]);

            
            // Saida emitida para sites/estaleiros
            if (Auth::user()->tipo_de_usuario == 7  && $guia->empresa_id != 7 && $guia->projecto != null) {
                $this->gerar_entrada($id);
            }
            
            // return 'done!';
            DB::commit();

            $this->toaster('success', 'Processo aprovado com sucesso!'); 
            return redirect()->route('guiasaida.show', $id);

        } catch (\Throwable $error) {
             
            DB::rollback(); 
             
            $this->toaster('error', 'Erro ao tentar aprovar processo!');
            return redirect()->back();

        }
    }

    function gerar_entrada($saida_id) {

        $saida = GuiaDeSaida::find($saida_id);

        $saida_proj = Null;

        if ($saida->site == null || $saida->site == 0) {
            $saida_proj = Site::where('projecto',$saida->projecto)->first();
            $saida_proj = $saida_proj->id;
        }else {
            $saida_proj = $saida->site;
        }

        $entrada = Guiadeentrada::create([
            'origem' => 1,
            'data' => date('Y-m-d'),
            'site' => $saida_proj, 
            'anexo' => $saida->anexo, 
            // 'projecto' => $saida->projecto, 
            'numero_do_folheto' => $this->count_referencia_entradas(),
            'empresa_id' => 1,
            'responsavel' => Auth::user()->name,
            'elaborado_por' => Auth::user()->name . 'Data: ' . date('d/m/Y') . ' -  Hora: ' . date('H : i : s'),
        ]);

        $produtos = GuiaSaidaProduto::where([['guiaSaida_id', $saida_id], ['status', 1]])->get();

        foreach ($produtos as $value) {
            # code...
            GuiaEntrada_Produto::create([
                'produto_id' => $value->produto_id,
                'quantidade' => $value->quantidade,
                'guiaEntrada_id' => $entrada->id
            ]);
        }

        // Na emissao de guia de saida para estaleiro, ele pega o projecto e o site, depois de se aprovar 
        // ele remove o site e mantem o projecto, para que a saida seja feita no projecto e nao no site
        if (Auth::user()->tipo_de_usuario == 7  && $saida->empresa_id != 7) {
            GuiaDeSaida::where('id',$saida_id)->update(['site' => Null]);
        }
    }

    public function count_referencia_entradas()
    {
        $comprasCount = $this->entrada->countByCompany();
        if ($comprasCount > 0) {
            $orderReference = $this->entrada->getLastComprasByEmpresa();

            $ref = explode('-', $orderReference->numero_do_folheto);
            $compras_count = (int) $ref[1];
        } else {
            $compras_count = 0;
        }
        
        $iniciais = 'ES';

        $referencia =
            $compras_count > 0
            ? $iniciais.'-' .
            sprintf('%04d', $compras_count + 1) .
            '/' .
            date('Y')
        : $iniciais.'-' . 0001;

        return $referencia;

    }

    // Imprimir
    public function imprimir($id)
    {

        $guia = GuiaDeSaida::where('status', 1)->where('pendente', 2)->find($id);
       
        if (!$guia || Auth::user()->tipo_de_usuario == 3) {
            return redirect()->route('guiasaida.show', $id);
        }
        $pdf = PDF::loadView('print.guiadesaida', compact('guia'));
        $pdf->setPaper([0, 0, 750, 1060], 'portrait');
        return $pdf->stream('guiadesaida.pdf', [
            'Attachment' => 0,
        ]);
    }


    // Pesquisa function
    public function pesquisa(Request $request)
    {
         
        
        $user_project = $this->user_project->get_user_projects();
        $user_sites = $this->user_project->get_user_sites();

        // 7 Gestor de Projecto!!
        if (Auth::user()->tipo_de_usuario == 7) {
            $guiadesaidas = GuiadeSaida::with(['requisicaoArmazem', 'empresa'])
                ->select('guia_de_saidas.*', 'site.nome as nome_site', 'projecto.nome as nome_projecto')
                ->leftJoin('projecto', 'projecto.id', '=', 'guia_de_saidas.projecto')
                ->leftJoin('site', 'site.id', '=', 'guia_de_saidas.site')
                ->where([['empresa_id', '!=', 7], ['guia_de_saidas.numero_do_folheto', '<>', 'AJUSTE'],  ['guia_de_saidas.numero_do_folheto', '<>', 'TRANSFERENCIA'], ['origem', 1], ['role_id', Auth::user()->role_id]])
                ->whereIn('guia_de_saidas.projecto', $user_project)
                // ->whereIn('guia_de_saidas.site', $user_sites)
                ->orderBy('guia_de_saidas.id', 'desc')
            ->get();

        } else {

            $guiadesaidas = GuiadeSaida::with(['requisicaoArmazem', 'empresa'])
                ->select('guia_de_saidas.*', 'site.nome as nome_site', 'projecto.nome as nome_projecto')
                ->leftJoin('site', 'site.id', '=', 'guia_de_saidas.site')
                ->leftJoin('projecto', 'projecto.id', '=', 'site.projecto')
                ->where([['empresa_id', '!=', 7], ['guia_de_saidas.numero_do_folheto', '<>', 'AJUSTE'],  ['guia_de_saidas.numero_do_folheto', '<>', 'TRANSFERENCIA'], ['origem', 1], ['role_id', Auth::user()->role_id]])
                ->whereNull('guia_de_saidas.projecto')
                ->whereIn('guia_de_saidas.site', $user_sites)
                ->orderBy('guia_de_saidas.id', 'desc')
            ->get();

        }
        
 
        

        return $guiadesaidas;
    }
 
}
