<?php

namespace App\Http\Controllers;

use App\Models\GuiaEntrada_Produto;
use App\Models\Guiadeentrada;
use App\Models\GuiaDeSaida;
use App\Models\Produto; 
use App\Models\UsuarioProjecto;
use App\Models\StockProjectado; 
use Illuminate\Http\Request;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\IOFactory;
use Illuminate\Support\Facades\Auth;
use DB;

class ProjectoStockFilterDataController extends Controller
{

    
    protected $user_project;
    public function __construct(UsuarioProjecto $user_project)
    {
        $this->user_project = $user_project;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    { 

        $projects_id = $this->user_project->get_user_projects();
        $data['projectos'] = DB::table('projecto')
            ->whereIn('id', $projects_id)
            ->where('removido',0)
        ->get();

        return view('admin.stock.date', $data);
    }
 

    // Pesquisa function
    public function pesquisa(Request $request)
    {

        $filters = $request->except('_token');
        $meses = Produto::orderBy('created_at', 'desc')->get()->groupBy(function ($item) {
            return $item->created_at->format('Y-m');
        });
 
        // Pesquisa total por search
        if ($request->pesquisa) {
            
            $produtos = $this->searchtotal($request);
            $produtos = $this->produtos($produtos, $request->datainicio, $request->datafim, $request->projecto);
            return response()->json(['produtos' => $produtos], 200);
        }

        // Pesquisa vazia
        $meses = Produto::orderBy('created_at', 'desc')->get()->groupBy(function ($item) {
            return $item->created_at->format('Y-m');
        });
        
        $mes = Produto::first()->created_at->format('Y-m');
        $data = $mes;
 
        $todosProdutos = $this->get_produtos_guias($request->projecto);

        $produtos = $this->produtos($todosProdutos, $request->datainicio, $request->datafim, $request->projecto);
 
        return response()->json(['produtos' => $produtos, 'meses' => $meses, 'data' => $data]); 
    }

    // Metodos que pega os Id's dos produtos projectados pra esse projecto;
    public function get_produtos_guias($projecto)
    {
        if ($projecto != Null) { 
            // Projeccoes, Adendas, Acrescimos, Guias de Saida

            $guia = Guiadeentrada::where([['projecto', $projecto], ['role_id', Auth::user()->role_id]])
                ->leftJoin('guia_entrada__produtos', 'guia_entrada__produtos.guiaEntrada_id', 'guiadeentradas.id')
                ->groupBy('guia_entrada__produtos.produto_id')
            ->pluck('guia_entrada__produtos.produto_id');
            
        }else {

            // Sites do usuario!
            $get_user_projects = $this->user_project->get_user_projects();
            // Projeccoes, Adendas, Acrescimos, Guias de Saida

            $guia = Guiadeentrada::whereIn('projecto', $get_user_projects)
                ->where('role_id', Auth::user()->role_id)
                ->leftJoin('guia_entrada__produtos', 'guia_entrada__produtos.guiaEntrada_id', 'guiadeentradas.id')
                ->groupBy('guia_entrada__produtos.produto_id')
            ->pluck('guia_entrada__produtos.produto_id');
        }
         
        $todosProdutos = Produto::with('categoria.father')
            ->whereHas('categoria', function ($q) {
                $q->where('status', 1);
            })
            ->where('status', 1)->orderBy('categoria_id')->orderBy('nome', 'asc')
            ->whereIn('id', $guia)
            ->groupBy('produtos.id')
        ->get();

        return $todosProdutos;
    }

    
    // Pesquisa total de search
    public function searchtotal($request)
    {

        return $produtos = Produto::with('categoria.father')->where('status', 1)->Where('nome', 'LIKE', $request->pesquisa . '%')
            ->orWhere('codigo', 'LIKE', $request->pesquisa . '%')
            ->orWhereHas('categoria', function ($q) use ($request) {
                $q->where('nome', 'LIKE', $request->pesquisa . '%')->where('status', 1);
            })
            ->orWhereHas('categoria', function ($q) use ($request) {
                $pai = $request;
                $q->where('status', 1)->WhereHas('father', function ($f) use ($pai) {
                    $f->where('nome', 'LIKE', $pai->pesquisa . '%');
                });
            })->orderBy('categoria_id')
        ->get(); 
    }

    public function totalEntrada($id, $data_inicio, $data_fim, $projecto)
    {

        
         
        if ($projecto != 0 && $projecto != NULL) {
           
            $condition = [['tipo', 1], ['origem', 1], ['role_id', Auth::user()->role_id], ['projecto', $projecto]];

            $produto = Produto::with([
                'categoria.father', 'entradaTotal' => function ($q) use ($condition) {

                    $q->whereHas('guiaDeEntrada', function ($q) use ($condition) {
                        $q->where($condition);
                    });
                }
            ])->where('status', 1)->find($id);

        } else {

            $produto = Produto::with([
                'categoria.father', 'entradaTotal' => function ($q) {

                    $q->whereHas('guiaDeEntrada', function ($q) {
                        $q->where([['origem', 1], ['role_id', Auth::user()->role_id]]);
                    });
                }
            ])->where('status', 1)->find($id);

        }
        $total = ($produto->entradaTotal_counter($projecto));
        return ['produto' => $produto, 'total' => $total];
    }

    public function totalProjected($id, $data_inicio, $data_fim, $projecto)
    {
 
        $count = 0;
        $dataSomada = strtotime($data_inicio . ' +1 day');  
        $data_inicio = date('Y-m-d', $dataSomada); 

        if ($projecto != 0 && $projecto != NULL) {
           
            $condition = [['projecto', $projecto], ['status', 0], ['stock_projectado_produtos.produto_id', $id], ['role_id', Auth::user()->role_id]];

            return $data = DB::table('stock_projectado')
                ->leftJoin('stock_projectado_produtos', 'stock_projectado.id', '=', 'stock_projectado_produtos.projectado_id')
                ->where($condition)
            ->sum('quantidade');

        } else {

            $condition = [['projecto', '!=', NULL], ['status', 0], ['stock_projectado_produtos.produto_id', $id], ['role_id', Auth::user()->role_id]];

            return $data = DB::table('stock_projectado')
                ->leftJoin('stock_projectado_produtos', 'stock_projectado.id', '=', 'stock_projectado_produtos.projectado_id')
                ->where($condition)
                ->whereNotNull('site')
            ->sum('quantidade');

        }
        
    }
 
    public function totalSaida($id, $data_inicio, $data_fim, $projecto)
    {

        $dataSomada = strtotime($data_fim . ' -0 day'); // Exemplo de saída: 1565064000
        $data_fim = date('Y-m-d', $dataSomada); // 06/08/2019

        if ($projecto != 0 && $projecto != NULL) {
            $condition = [['role_id', Auth::user()->role_id], ['tipo', 1], ['origem', 1], ['projecto', $projecto] ];

            $produto = Produto::with([
                'categoria.father', 'saidaTotal' => function ($q) use ($data_inicio, $data_fim, $condition) {

                    $q->whereHas('guiaSaida', function ($q) use ($data_inicio, $data_fim, $condition) {
                        $q->where($condition);
                    });
                }
            ])->where('status', 1)->find($id);

        } else {

            $user_projects = $this->user_project->get_user_projects();
            $condition = [['role_id', Auth::user()->role_id], ['tipo', 1], ['origem', 1]];

            $produto = Produto::with([
                'categoria.father', 'saidaTotal' => function ($q) use ($data_inicio, $data_fim, $user_projects, $condition) {

                    $q->whereHas('guiaSaida', function ($q) use ($data_inicio, $data_fim, $user_projects, $condition) {
                        $q->whereIn('projecto', $user_projects)->where($condition);
                    });
                }
            ])->where('status', 1)->find($id);

        }
        
        // $total = ($produto->saidaTotal->sum('quantidade'));
        $total = ($produto->saidaTotal_counter($projecto));
        
        return ['produto' => $produto, 'total' => $total];
    }
  
    public function totalProjectado($produto_id, $projecto)
    {
            
        $user_project = $this->user_project->get_user_projects();

        if ($projecto != 0 || $projecto != Null) {
            # code...
            $total =  DB::table('stock_projectado') 
                ->leftJoin('stock_projectado_produtos', 'stock_projectado_produtos.projectado_id', 'stock_projectado.id') 
                ->where([['stock_projectado.projecto' , $projecto],  ['stock_projectado_produtos.produto_id' , $produto_id],  ['stock_projectado.removido', 0], ['role_id', Auth::user()->role_id], ['status', 0]])
            ->SUM('stock_projectado_produtos.quantidade');
            
        } else {
            # code...
            $total =  DB::table('stock_projectado') 
                ->leftJoin('stock_projectado_produtos', 'stock_projectado_produtos.projectado_id', 'stock_projectado.id') 
                ->whereIn('projecto', $user_project)
                ->where('stock_projectado_produtos.produto_id', $produto_id)
            ->SUM('stock_projectado_produtos.quantidade');
        }
        
            
        return ['total' => $total];
    }

    public function totalAjuste($produto_id, $projecto, $type)
    {
        // $type ??
        // 1 - Adenda; 2 - Acrescimo	
      
        $user_project = $this->user_project->get_user_projects();

        if ($projecto != 0 || $projecto != Null) {

            $total =  DB::table('ajustes_projeccao') 
                ->leftJoin('ajustes_projeccao_produtos', 'ajustes_projeccao_produtos.ajuste_projeccao_id', 'ajustes_projeccao.id') 
                ->leftJoin('stock_projectado', 'stock_projectado.id', 'ajustes_projeccao.projeccao_id') 
                ->where([
                    ['stock_projectado.projecto' , $projecto], ['ajustes_projeccao_produtos.produto_id' , $produto_id], ['ajustes_projeccao.tipo_ajuste', $type], ['ajustes_projeccao.removido', 0]
                ])
            ->SUM('ajustes_projeccao_produtos.quantidade');
            
        } else {
        
            $total =  DB::table('ajustes_projeccao') 
                ->leftJoin('ajustes_projeccao_produtos', 'ajustes_projeccao_produtos.ajuste_projeccao_id', 'ajustes_projeccao.id') 
                ->leftJoin('stock_projectado', 'stock_projectado.id', 'ajustes_projeccao.projeccao_id')  
                ->whereIn('stock_projectado.projecto', $user_project)
                ->where([['ajustes_projeccao_produtos.produto_id', $produto_id], ['ajustes_projeccao.tipo_ajuste', $type], ['ajustes_projeccao.removido', 0]])
            ->SUM('ajustes_projeccao_produtos.quantidade');
        }
            
        return ['total' => $total];
    }


    public function AjusteEntrada($id, $data_inicio, $data_fim, $site)
    {

        $condition = ($site != 0) ? 
        [['site', $site], ['origem', 1], ['numero_do_folheto' , 'AJUSTE'], ['role_id', Auth::user()->role_id]] : 
        [['origem', 1], ['numero_do_folheto' , 'AJUSTE'], ['role_id', Auth::user()->role_id]];
        
        $produto = Produto::with([
            'categoria.father', 'entradaTotal' => function ($q) use ($data_inicio, $data_fim, $condition) {
                $q->whereHas('guiaDeEntrada', function ($q) use ($data_inicio, $data_fim, $condition) {
                    $q->whereBetween('data', [$data_inicio, $data_fim])->where($condition);
                });
            }
        ])->find($id);
  
        
        return ['produto' => $produto, 'total' => $produto->entradaTotal_ajusteBtwn($site,$data_inicio, $data_fim)];
    }

    public function transferido($id, $data_inicio, $data_fim, $projecto)
    {

        $condition = ($projecto != 0 ||  $projecto != Null) ? 
        [['requisicao_transferencia.empresa_origem', $projecto], ['requisicao_transferencia_produtos.produto_id', $id], ['requisicao_transferencia.status', 2], ['role_id', Auth::user()->role_id]] : 
        [['requisicao_transferencia.status', 2], ['requisicao_transferencia_produtos.produto_id', $id], ['role_id', Auth::user()->role_id]];
        
         
        $user_project = $this->user_project->get_user_projects();

        if ($projecto != 0 || $projecto != Null) {

            $total =  DB::table('requisicao_transferencia') 
                ->leftJoin('requisicao_transferencia_produtos', 'requisicao_transferencia_produtos.requisicao_id', 'requisicao_transferencia.id') 
                ->where($condition)
            ->SUM('requisicao_transferencia_produtos.quantidade');
            
        } else {
            
            $total =  DB::table('requisicao_transferencia') 
                ->leftJoin('requisicao_transferencia_produtos', 'requisicao_transferencia_produtos.requisicao_id', 'requisicao_transferencia.id') 
                ->whereIn('requisicao_transferencia.empresa_origem', $user_project)
                ->where($condition)
            ->SUM('requisicao_transferencia_produtos.quantidade');
        }
            
        return ['total' => $total];
    }


 
    public function AjusteSaida($id, $data_inicio, $data_fim, $projecto)
    {

        $condition = ($projecto != 0) ? 
        [['projecto', $projecto], ['origem', 1], ['numero_do_folheto' , 'AJUSTE'], ['role_id', Auth::user()->role_id]] : 
        [['origem', 1], ['numero_do_folheto' , 'AJUSTE'], ['role_id', Auth::user()->role_id]];
 
        $produto = Produto::with([
            'categoria.father', 'saidaTotal' => function ($q) use ($data_inicio, $data_fim, $condition) {

                $q->whereHas('guiaSaida', function ($q) use ($data_inicio, $data_fim, $condition) {
                    $q->whereBetween('data', [$data_inicio, $data_fim])->where($condition);
                });
            }
        ])->find($id);

        $total = ($produto->saidaTotal_counter_ajusteBtwn($projecto, $data_inicio, $data_fim));

        return ['produto' => $produto, 'total' => $total];
    }


    public function produtos($todosProdutos, $data_inicio, $data_fim, $projecto)
    {
        $ver = ''; 
        $index = 1;
        $produtos = '';

        foreach ($todosProdutos as $produto) {
            if ($ver != $produto->categoria->nome) {
                $categoria = '<tr>
                    <td colspan="6" style = "font-size: 14px !important" align="center" class="font-weight-bold tcategoria titleProductCategorie text-danger">' . $produto->categoria->nome  . '</td>
                </tr>';
                $ver = $produto->categoria->nome;
            } else {
                $categoria = '';
            }
            
            $total_entrada = $this->totalEntrada($produto->id, $data_inicio, $data_fim, $projecto)['total'];
            $projeccao = $this->totalProjected($produto->id, $data_inicio, $data_fim, $projecto);
            $total_saida = $this->totalSaida($produto->id, $data_inicio, $data_fim, $projecto)['total'];
            $saida_final = $total_entrada - $total_saida; 
            
            $produtos = 
    
            $produtos . ' ' . $categoria . '
            <tr style = "" class= "blink-bg">

                <td class="text-center" style="text-align: right; white-space: nowrap;width: 100px; font-size: 13px">
                    &nbsp; ' . $index++ . '
                </td>
                <td  style="width: 197.153px; white-space: nowrap; font-size: 13px">
                    &nbsp;' . $produto->codigo . '
                </td>
                <td style="white-space: nowrap; font-size: 13px"> 
                    &nbsp;&nbsp;' . $produto->nome . '
                </td>
                <td style="text-align: right; white-space: nowrap;width: 100px; font-size: 13px" >
                    &nbsp;&nbsp;' . number_format($projeccao) . '&nbsp;
                </td> 
                <td style="text-align: right; white-space: nowrap;width: 100px; font-size: 13px" >
                    ' . number_format($total_entrada) . '  &nbsp;
                </td>
                <td style="text-align: right; white-space: nowrap;width: 100px; font-size: 13px" >
                    ' . number_format($total_saida) . '  &nbsp;
                </td>  
                <td style="text-align: right; white-space: nowrap;width: 100px; font-size: 13px"  class="font-weight-bold text-danger">
                    ' . number_format($saida_final) . '  &nbsp;
                </td>

            </tr>';
            
            
        }
        return $produtos;
    }
 

    public function stockpage(){
        return view('admin.stockpages.date');
    }

    
    public function ajustes_stock($id, $projecto = Null){
        
        return redirect()->back()->with('success', 'Volte a tentar mais tarde!');
        $condition = ($projecto != 0) ? ['projecto'=> $projecto, 'numero_do_folheto' => 'AJUSTE'] : ['numero_do_folheto' => 'AJUSTE']; 
        
        return Guiadeentrada::select('guiadeentradas.id as guia_saida_id', DB::raw('SUM(guia_entrada__produtos.quantidade) as quantidade'), 'guiadeentradas.numero_do_folheto', 'guiadeentradas.data')
            ->where($condition)
            ->leftJoin('guia_entrada__produtos', 'guia_entrada__produtos.guiaEntrada_id', 'guiadeentradas.id')
            ->leftJoin('guia_entrada__produtos', 'guia_entrada__produtos.guiaEntrada_id', 'guiadeentradas.id')
        ->get();

        return view('admin.pesquisas.entradasSaidas.ajustes');
    }
}
 