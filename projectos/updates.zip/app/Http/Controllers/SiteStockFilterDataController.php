<?php

namespace App\Http\Controllers;

use App\Models\GuiaEntrada_Produto;
use App\Models\Guiadeentrada;
use App\Models\GuiaDeSaida;
use App\Models\ProdutoSite;
use App\Models\UsuarioProjecto;
use App\Models\StockProjectado; 
use Illuminate\Http\Request;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\IOFactory;
use Illuminate\Support\Facades\Auth;

use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

use DB;

class SiteStockFilterDataController extends Controller
{

    
    protected $user_project;
    public function __construct(UsuarioProjecto $user_project)
    {
        $this->user_project = $user_project;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        
        // return $this->totalDanificado(1558, '2020-10-02', '2024-10-02', 71);
        
        $sites_id = $this->user_project->get_user_sites();
        $data['sites'] = DB::table('site')
            ->whereIn('id', $sites_id)
            ->where('removido',0)
        ->get();

        return view('admin.stock_sites.date', $data);
    }
 

    // Pesquisa function
    public function pesquisa(Request $request)
    {
        $filters = $request->except('_token');
        $meses = ProdutoSite::orderBy('created_at', 'desc')->get()->groupBy(function ($item) {
            return $item->created_at->format('Y-m');
        });
 
        // Pesquisa total por search
        if ($request->pesquisa) {
            $produtos = $this->searchtotal($request);
            $produtos = $this->produtos($produtos, $request->datainicio, $request->datafim, $request->site);
            return response()->json(['produtos' => $produtos], 200);
        }

        // Pesquisa vazia
        $meses = ProdutoSite::orderBy('created_at', 'desc')->get()->groupBy(function ($item) {
            return $item->created_at->format('Y-m');
        });
        
        $mes = ProdutoSite::first()->created_at->format('Y-m');
        $data = $mes;

        $data_inicial = $request->datainicio ? $request->datainicio : '2018-01-01';

        $todosProdutos = $this->get_produtos_guias($request->site, $data_inicial, $request->datafim);
        /*
        return response()->json([
            'data' => $todosProdutos
        ]);
        */
        $produtos = $this->produtos($todosProdutos, $data_inicial, $request->datafim, $request->site);
 
        return response()->json(['produtos' => $produtos, 'meses' => $meses, 'data' => $data]); 
    }

    // Metodos que pega os Id's dos produtos com entradas pra esse projecto;
    public function get_produtos_guias($site, $data_inicial = '2018-01-01', $data_final = null)
    {
        if ($site != Null) {
            // Projeccoes, Adendas, Acrescimos, Guias de Saida

            $guia = Guiadeentrada::where([['site', $site], ['role_id', Auth::user()->role_id]])
                ->whereBetween('guiadeentradas.created_at', [$data_inicial, $data_final])
                ->leftJoin('guia_entrada__produtos', 'guia_entrada__produtos.guiaEntrada_id', 'guiadeentradas.id')
                ->groupBy('guia_entrada__produtos.produto_id')
            ->pluck('guia_entrada__produtos.produto_id');

            $guia_saida = GuiaDeSaida::where([['site', $site], ['role_id', Auth::user()->role_id]])
                ->whereBetween('guia_de_saidas.created_at', [$data_inicial, $data_final])
                ->leftJoin('guia_saida_produtos', 'guia_saida_produtos.guiaSaida_id', 'guia_de_saidas.id')
                ->groupBy('guia_saida_produtos.produto_id')
            ->pluck('guia_saida_produtos.produto_id');

            $projeccao = DB::table('stock_projectado')->where([['site', $site], ['stock_projectado.role_id', Auth::user()->role_id]])
                ->leftJoin('stock_projectado_produtos', 'stock_projectado_produtos.projectado_id', 'stock_projectado.id')
                ->groupBy('stock_projectado_produtos.produto_id')
            ->pluck('stock_projectado_produtos.produto_id');

            $ajuste = DB::table('ajustes_projeccao')->where([['stock_projectado.site', $site], ['ajustes_projeccao.role_id', Auth::user()->role_id]])
                ->leftJoin('stock_projectado', 'stock_projectado.id', 'ajustes_projeccao.projeccao_id')
                ->leftJoin('ajustes_projeccao_produtos', 'ajustes_projeccao_produtos.ajuste_projeccao_id', 'ajustes_projeccao.id')
            ->pluck('ajustes_projeccao_produtos.produto_id');

        } else {

            // Sites do usuario!
            $get_user_sites = $this->user_project->get_user_sites();
            // Projeccoes, Adendas, Acrescimos, Guias de Saida

            $guia = Guiadeentrada::whereIn('site', $get_user_sites)
                ->whereBetween('guiadeentradas.created_at', [$data_inicial, $data_final])
                ->where('role_id', Auth::user()->role_id)
                ->leftJoin('guia_entrada__produtos', 'guia_entrada__produtos.guiaEntrada_id', 'guiadeentradas.id')
                ->groupBy('guia_entrada__produtos.produto_id')
                ->pluck('guia_entrada__produtos.produto_id');

            $guia_saida = GuiaDeSaida::whereIn('site', $get_user_sites)
                ->whereBetween('guia_de_saidas.created_at', [$data_inicial, $data_final])
                ->where('role_id', Auth::user()->role_id)
                ->leftJoin('guia_saida_produtos', 'guia_saida_produtos.guiaSaida_id', 'guia_de_saidas.id')
                ->groupBy('guia_saida_produtos.produto_id')
            ->pluck('guia_saida_produtos.produto_id');

            $projeccao = DB::table('stock_projectado')->whereIn('site', $get_user_sites)
            ->where('stock_projectado.role_id', Auth::user()->role_id)
                ->leftJoin('stock_projectado_produtos', 'stock_projectado_produtos.projectado_id', 'stock_projectado.id')
                ->groupBy('stock_projectado_produtos.produto_id')
            ->pluck('stock_projectado_produtos.produto_id');

            $ajuste = DB::table('ajustes_projeccao')->whereIn('stock_projectado.site', $get_user_sites)
                ->where('stock_projectado.role_id', Auth::user()->role_id)
                ->leftJoin('stock_projectado', 'stock_projectado.id', 'ajustes_projeccao.projeccao_id')
                ->leftJoin('ajustes_projeccao_produtos', 'ajustes_projeccao_produtos.ajuste_projeccao_id', 'ajustes_projeccao.id')
            ->pluck('ajustes_projeccao_produtos.produto_id');
        }

        $guia->merge($guia_saida);

        $todosProdutos = ProdutoSite::with('categoria.father')
        //    ->whereBetween('created_at', [$data_inicial, $data_final])
            ->whereHas('categoria', function ($q) {
                $q->where('status', 1);
            })
            ->where('status', 1)->orderBy('categoria_id')->orderBy('nome', 'asc')
            ->whereIn('id', $guia)
            ->OrwhereIn('id', $projeccao)
            ->groupBy('produtos.id')
        ->get();

        return $todosProdutos;
    }

 
    // Pesquisa total de search
    public function searchtotal($request)
    {

        return $produtos = ProdutoSite::with('categoria.father')->where('status', 1)->Where('nome', 'LIKE', $request->pesquisa . '%')
            ->orWhere('codigo', 'LIKE', $request->pesquisa . '%')
            ->orWhereHas('categoria', function ($q) use ($request) {
                $q->where('nome', 'LIKE', $request->pesquisa . '%')->where('status', 1);
            })
            ->orWhereHas('categoria', function ($q) use ($request) {
                $pai = $request;
                $q->where('status', 1)->WhereHas('father', function ($f) use ($pai) {
                    $f->where('nome', 'LIKE', $pai->pesquisa . '%');
                });
            })->orderBy('categoria_id')
        ->get(); 
    }

   
    public function totalEntrada($id, $data_inicio, $data_fim, $site)
    {

        
        $dataSomada = strtotime($data_inicio . ' +1 day');  
        $data_inicio = date('Y-m-d', $dataSomada); 
        if ($site != 0 && $site != NULL) {
           
            $condition = [['numero_do_folheto', '<>', 'AJUSTE'], ['tipo', 1], ['site', $site]];

            $produto = ProdutoSite::with([
                'categoria.father', 'entradaTotal' => function ($q) use ($data_inicio, $data_fim, $condition) {

                    $q->whereHas('guiaDeEntrada', function ($q) use ($data_inicio, $data_fim, $condition) {
                        $q->whereBetween('data', [$data_inicio, $data_fim])
                        ->where($condition);
                    });
                }
            ])->where('status', 1)->find($id);

        } else {

            $user_sites = $this->user_project->get_user_sites();
            $produto = ProdutoSite::with([
                'categoria.father', 'entradaTotal' => function ($q) use ($data_inicio, $data_fim, $user_sites) {

                    $q->whereHas('guiaDeEntrada', function ($q) use ($data_inicio, $data_fim, $user_sites) {
                        $q->whereBetween('data', [$data_inicio, $data_fim])
                        ->where('site','!=', Null)
                        ->whereIn('site', $user_sites);
                    });
                }
            ])->where('status', 1)->find($id);

        }
        $total = ($produto->entradaTotal_counter($site));
        return ['produto' => $produto, 'total' => $total];
    }


    public function totalProjectado($id, $data_inicio, $data_fim, $site)
    {
 
        $count = 0;
        $dataSomada = strtotime($data_inicio . ' +1 day');  
        $data_inicio = date('Y-m-d', $dataSomada); 

        if ($site != 0 && $site != NULL) {
           
            $condition = [['site', $site], ['status', 0], ['stock_projectado_produtos.produto_id', $id], ['role_id', Auth::user()->role_id]];

            return $data = DB::table('stock_projectado')
                ->leftJoin('stock_projectado_produtos', 'stock_projectado.id', '=', 'stock_projectado_produtos.projectado_id')
                ->where($condition)
            ->sum('quantidade');

        } else {

            $condition = [['site', '!=', NULL], ['status', 0], ['stock_projectado_produtos.produto_id', $id], ['role_id', Auth::user()->role_id]];

            return $data = DB::table('stock_projectado')
                ->leftJoin('stock_projectado_produtos', 'stock_projectado.id', '=', 'stock_projectado_produtos.projectado_id')
                ->where($condition)
                ->whereNotNull('site')
            ->sum('quantidade');

        }
        
    }


 
    public function totalSaida($id, $data_inicio, $data_fim, $site)
    {

        $dataSomada = strtotime($data_fim . ' -0 day'); // Exemplo de saída: 1565064000
        $data_fim = date('Y-m-d', $dataSomada); // 06/08/2019

        if ($site != 0 && $site != NULL) {
            $condition = [['numero_do_folheto', '<>', 'AJUSTE'], ['tipo', 1], ['site', $site], ['projecto', '=',Null]];

            $produto = ProdutoSite::with([
                'categoria.father', 'saidaTotal' => function ($q) use ($data_inicio, $data_fim, $condition) {

                    $q->whereHas('guiaSaida', function ($q) use ($data_inicio, $data_fim, $condition) {
                        $q->whereBetween('data_do_recebimento', [$data_inicio, $data_fim])
                        ->where($condition);
                    });
                }
            ])->where('status', 1)->find($id);

        } else {
            $user_site = $this->user_project->get_user_sites();

            $produto = ProdutoSite::with([
                'categoria.father', 'saidaTotal' => function ($q) use ($data_inicio, $data_fim, $user_site) {

                    $q->whereHas('guiaSaida', function ($q) use ($data_inicio, $data_fim, $user_site) {
                        $q->whereBetween('data_do_recebimento', [$data_inicio, $data_fim])
                        ->whereIn('site', $user_site);
                    });
                }
            ])->where('status', 1)->find($id);

        }
         
        $total = ($produto->saidaTotal_counter($site));
        
        return ['produto' => $produto, 'total' => $total];
    }
 
 
 
    public function totalDanificado($id, $data_inicio, $data_fim, $site)
    {
        
        $dataSomada = strtotime($data_inicio . ' +1 day');  
        $data_inicio = date('Y-m-d', $dataSomada); 

    
        

        $produto = ProdutoSite::with([
            'categoria.father', 'entradaTotal' => function ($q) use ($data_inicio, $data_fim, $site) {
                $q->whereHas('guiaDeEntrada', function ($q) use ($data_inicio, $data_fim, $site) {
                    $q->whereBetween('data', [$data_inicio, $data_fim]);
                });
            }
        ])->find($id);


        $total = $produto->danificado($site)->sum('quantidade_danificado');
        
        return ['total' => $total];
    }
 

    public function produtos($todosProdutos, $data_inicio, $data_fim, $site)
    {
        $ver = ''; 
        $index = 1;
        $produtos = '';

        foreach ($todosProdutos as $produto) {
            if ($ver != $produto->categoria->nome) {
                $categoria = '
                <tr>
                    <td  class="font-weight-bold">' . '' . '</td>
                    <td  align="center" class="font-weight-bold" style="white-space: nowrap">' . '' . '</td>
                    <td  style = "font-size: 14px !important" align="center" class="font-weight-bold tcategoria titleProductCategorie text-danger">' . $produto->categoria->nome  . '</td>
                    
                    <td  align="center" class="font-weight-bold" style="white-space: nowrap">' . '' . '</td>
                    <td  align="center" class="font-weight-bold" style="white-space: nowrap">' . '' . '</td>
                    <td  align="center" class="font-weight-bold" style="white-space: nowrap">' . '' . '</td>
                    <td  align="center" class="font-weight-bold" style="white-space: nowrap">' . '' . '</td>
                    <td  align="center" class="font-weight-bold" style="white-space: nowrap">' . '' . '</td>
                </tr>';
                $ver = $produto->categoria->nome;
            } else {
                $categoria = '';
            }
            
            $total_entrada = $this->totalEntrada($produto->id, $data_inicio, $data_fim, $site)['total'];
            $projeccao = $this->totalProjectado($produto->id, $data_inicio, $data_fim, $site);
            $total_saida = $this->totalSaida($produto->id, $data_inicio, $data_fim, $site)['total'];
            $danificado = $this->totalDanificado($produto->id, $data_inicio, $data_fim, $site)['total'];
            $saida_final = $total_entrada - $total_saida;  

            
            // if ($total_entrada != 0 && $total_saida != 0) {
                ($total_entrada + $total_saida) > 0 ? $produtos = 
        
                $produtos . ' ' . $categoria . '
                <tr>

                    <td class="text-center">
                        ' . $index++ . '
                    </td>
                    <td class="text-center" style="width: 197.153px; white-space: nowrap; font-size: 13px">
                        ' . $produto->codigo . '
                    </td>
                    <td style="white-space: nowrap; font-size: 13px" > 
                        &nbsp;&nbsp;' . $produto->nome . '
                    </td> 
                        
                    <td style="text-align: right; white-space: nowrap;width: 100px; font-size: 13px" >
                        &nbsp;&nbsp;' . number_format($projeccao) . '&nbsp;
                    </td>
                    <td style="text-align: right; white-space: nowrap;width: 100px; font-size: 13px" >
                        &nbsp;&nbsp;' . number_format($total_entrada) . '&nbsp;
                    </td>
                    <td style="text-align: right; white-space: nowrap;width: 100px" >
                        &nbsp;&nbsp;' . number_format($total_saida) . '&nbsp;
                    </td> 
                    <td style="text-align: right; white-space: nowrap;width: 100px" >
                        &nbsp;&nbsp;' . number_format($danificado) . '&nbsp;
                    </td> 
                    <td style="text-align: right; white-space: nowrap;width: 100px; font-size: 13px"  class="font-weight-bold">
                        &nbsp;&nbsp;' . number_format($saida_final) . '&nbsp; 
                    </td> 
                    
                </tr>'  : '';
            // }
            
            
        }
        return $produtos;
    }
 

    public function stockpage(){
        return view('admin.stockpages.date');
    }

    
    public function ajustes_stock($id, $projecto = Null){
        
        return redirect()->back()->with('success', 'Volte a tentar mais tarde!');
        $condition = ($projecto != 0) ? ['projecto'=> $projecto, 'numero_do_folheto' => 'AJUSTE'] : ['numero_do_folheto' => 'AJUSTE']; 
        
        return Guiadeentrada::select('guiadeentradas.id as guia_saida_id', DB::raw('SUM(guia_entrada__produtos.quantidade) as quantidade'), 'guiadeentradas.numero_do_folheto', 'guiadeentradas.data')
            ->where($condition)
            ->leftJoin('guia_entrada__produtos', 'guia_entrada__produtos.guiaEntrada_id', 'guiadeentradas.id')
            ->leftJoin('guia_entrada__produtos', 'guia_entrada__produtos.guiaEntrada_id', 'guiadeentradas.id')
        ->get();

        return view('admin.pesquisas.entradasSaidas.ajustes');
    }

    public function excell_fill($data, $estado_docs)
    {

        $reader = IOFactory::createReader('Xlsx');
        $spreadsheet = $reader->load(public_path('excel.xlsx'));
        $currentContentRow = 5;

        $spreadsheet->setActiveSheetIndex(0);
        $spreadsheet->getActiveSheet()->setCellValue('C3', 'Relatório De Requisições ' . $estado_docs . '');

        $total_sum = 0;

        foreach ($data as $index => $row) {
            $spreadsheet->getActiveSheet()->insertNewRowBefore($currentContentRow + 1, 1);
            // fill the cell with data

            $spreadsheet
                ->getActiveSheet()
                ->setCellValue('A' . $currentContentRow, $index + 1)
                ->setCellValue('B' . $currentContentRow, $row->data)
                ->setCellValue('C' . $currentContentRow, $row->referencia)
                ->setCellValue('D' . $currentContentRow, $row->nome)
                ->setCellValue('E' . $currentContentRow, $row->total);
            // increment the current row number
            $currentContentRow++;
            $total_sum += $row->total;
        }

        $spreadsheet
            ->getActiveSheet()
            ->setCellValue('E' . ($currentContentRow + 1), $total_sum);

        header(
            'Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        );
        header('Content-Disposition: attachment;filename="Relatorio_Requisições_' . $estado_docs . '.xlsx"');


        //create IOFactory object
        $writer = IOFactory::createWriter($spreadsheet, 'Xlsx');
        //save into php output
        $writer->save('php://output');
    }
}
 